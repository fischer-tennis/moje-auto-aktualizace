'use strict';
const $=id=>document.getElementById(id), key='mojeauto_v1';
let db={cars:[],records:[]}, editing=null, activeCar=null;
try{const x=JSON.parse(localStorage.getItem(key)||'null');if(x&&Array.isArray(x.cars)&&Array.isArray(x.records))db=x}catch{}
const save=()=>{try{localStorage.setItem(key,JSON.stringify(db));return true}catch(e){alert('Nepodařilo se uložit. Úložiště telefonu může být plné. Proveď zálohu a zmenši fotografie.');return false}};
const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random());
const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>Number(n||0).toLocaleString('cs-CZ',{style:'currency',currency:'CZK',maximumFractionDigits:0});
const date=d=>d?new Date(d+'T12:00:00').toLocaleDateString('cs-CZ'):'—';
function notice(s){$('toast').textContent=s;setTimeout(()=>$('toast').textContent='',3300)}
function showTab(t){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('active',e.id===t));document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('active',e.dataset.view===t));render()}
document.querySelectorAll('.tab').forEach(e=>e.addEventListener('click',()=>showTab(e.dataset.view)));
const carName=id=>{const c=db.cars.find(x=>x.id===id);return c?`${c.brand} ${c.model}`:'Neznámé auto'};
function render(){const cars=$('car-list');cars.innerHTML=db.cars.length?db.cars.map(c=>`<button class="car ${c.id===activeCar?'selected':''}" data-car="${html(c.id)}"><div><b>🚘 ${html(c.brand)} ${html(c.model)}</b><small>${html(c.plate||'Bez SPZ')} · ${html(c.year||'Rok neuveden')}</small></div><span>✎</span></button>`).join(''):'<div class="panel">Zatím nemáš uložené žádné auto. Začni tlačítkem „Přidat auto“.</div>';
cars.querySelectorAll('[data-car]').forEach(b=>b.onclick=()=>{activeCar=b.dataset.car;render();});
if(!db.cars.some(c=>c.id===activeCar))activeCar=db.cars[0]?.id||null;
$('overview-details').hidden=!activeCar;
if(activeCar){const rs=db.records.filter(r=>r.carId===activeCar);const odo=rs.filter(r=>Number(r.km)>0).sort((a,b)=>Number(b.km)-Number(a.km))[0];$('stats').innerHTML=`<div class="stat"><small>Vybrané auto</small><strong>${html(carName(activeCar))}</strong><button class="secondary" id="edit-car">Upravit auto</button></div><div class="stat"><small>Poslední stav tachometru</small><strong>${odo?Number(odo.km).toLocaleString('cs-CZ')+' km':'—'}</strong></div><div class="stat"><small>Celkové servisní náklady</small><strong>${money(rs.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</strong></div>`;$('edit-car').onclick=()=>openCar(activeCar);$('recent').innerHTML=listRecords(rs.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5));}
$('history-car').innerHTML='<option value="all">Všechna auta</option>'+db.cars.map(c=>`<option value="${html(c.id)}">${html(c.brand+' '+c.model)}</option>`).join('');const selected=$('history-car').dataset.selected||'all';$('history-car').value=[...$('history-car').options].some(o=>o.value===selected)?selected:'all';renderHistory();renderCosts();attachRecords();}
function listRecords(rows){if(!rows.length)return'<p class="note">Zatím žádné záznamy.</p>';return rows.map(r=>`<button class="record" data-rec="${html(r.id)}"><div><b>${r.type==='odo'?'📸':'🔧'} ${html(r.title)}</b><small>${html(carName(r.carId))} · ${date(r.date)} ${r.km?'· '+Number(r.km).toLocaleString('cs-CZ')+' km':''}</small></div><b>${r.type==='service'?money(r.price):'›'}</b></button>`).join('')}
function attachRecords(){document.querySelectorAll('[data-rec]').forEach(b=>b.onclick=()=>openRecord(b.dataset.rec))}
function renderHistory(){let rows=db.records;let car=$('history-car').value;if(car!=='all')rows=rows.filter(r=>r.carId===car);let q=$('history-search').value.trim().toLowerCase();if(q)rows=rows.filter(r=>(r.title+' '+r.note+' '+carName(r.carId)).toLowerCase().includes(q));$('history-list').innerHTML=listRecords(rows.slice().sort((a,b)=>b.date.localeCompare(a.date)));attachRecords()}
function renderCosts(){let sum=db.records.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0);$('costs-body').innerHTML=`<div class="stat"><small>Celkové servisní náklady</small><strong>${money(sum)}</strong></div>`+db.cars.map(c=>`<div class="record"><b>${html(c.brand+' '+c.model)}</b><b>${money(db.records.filter(r=>r.carId===c.id&&r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</b></div>`).join('')}
$('history-car').onchange=()=>{$('history-car').dataset.selected=$('history-car').value;renderHistory()};$('history-search').oninput=renderHistory;
function modal(title,body,onSubmit,onDelete){$('editor-title').textContent=title;$('editor-fields').innerHTML=body;$('editor').showModal();$('editor-form').onsubmit=e=>{e.preventDefault();onSubmit(new FormData(e.currentTarget))};$('delete-item').hidden=!onDelete;$('delete-item').onclick=()=>{if(confirm('Opravdu smazat?')){onDelete();$('editor').close();render()}}}
function close(){ $('editor').close();render() }$('close-dialog').onclick=close;$('cancel-dialog').onclick=close;
function openCar(id){const c=db.cars.find(x=>x.id===id)||{};modal(id?'Upravit auto':'Přidat auto',`<label>Značka<input name="brand" required value="${html(c.brand||'')}"></label><label>Model<input name="model" required value="${html(c.model||'')}"></label><label>SPZ<input name="plate" value="${html(c.plate||'')}"></label><label>Rok výroby<input name="year" inputmode="numeric" value="${html(c.year||'')}"></label><label>VIN (volitelné)<input name="vin" value="${html(c.vin||'')}"></label>`,f=>{const x={id:id||uid(),brand:f.get('brand').trim(),model:f.get('model').trim(),plate:f.get('plate').trim(),year:f.get('year').trim(),vin:f.get('vin').trim()};if(id)db.cars=db.cars.map(z=>z.id===id?x:z);else db.cars.push(x);activeCar=x.id;if(save())close()},id?()=>{db.cars=db.cars.filter(c=>c.id!==id);db.records=db.records.filter(r=>r.carId!==id);save()}:null)}
$('add-car').onclick=()=>openCar();
const today=()=>new Date().toLocaleDateString('sv-SE');
// OCR běží přímo v prohlížeči, bez odesílání fotografie na server.
const injectScript=(url)=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=url;s.onload=ok;s.onerror=()=>no(Error('Nepodařilo se načíst OCR knihovnu. Zkontroluj internet.'));document.head.appendChild(s)});
let ocrReady=false,pdfReady=false;
async function ocrImage(file,onProgress){if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}const worker=await Tesseract.createWorker('ces+eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení textu: '+Math.round((e.progress||0)*100)+' %')}});try{const r=await worker.recognize(file);return r.data.text}finally{await worker.terminate()}}
// Speciální OCR tachometru: zpracování displeje a oddělení celkových km od TRIP/času.
async function readOdometer(file,onProgress){
 if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}
 const img=await createImageBitmap(file);
 const width=img.width,height=img.height;
 const jobs=[
  {name:'celý snímek',box:[0,0,1,1],scale:1.6},
  {name:'střed displeje',box:[.20,.19,.62,.68],scale:2.6},
  {name:'dolní část displeje',box:[.13,.48,.73,.42],scale:3.4}
 ];
 const worker=await Tesseract.createWorker('eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Tachometr: '+Math.round((e.progress||0)*100)+' %')}});
 const candidates=[];const readings=[];
 try{
  await worker.setParameters({tessedit_pageseg_mode:Tesseract.PSM.SPARSE_TEXT});
  for(const job of jobs){
   onProgress('Rozpoznávám '+job.name+'…');
   const [x,y,w,h]=job.box,canvas=document.createElement('canvas');
   const sw=Math.round(width*w),sh=Math.round(height*h),scale=Math.min(job.scale,2600/Math.max(sw,sh));
   canvas.width=Math.max(1,Math.round(sw*scale));canvas.height=Math.max(1,Math.round(sh*scale));
   const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,Math.round(width*x),Math.round(height*y),sw,sh,0,0,canvas.width,canvas.height);
   const data=ctx.getImageData(0,0,canvas.width,canvas.height);
   for(let i=0;i<data.data.length;i+=4){const val=.299*data.data[i]+.587*data.data[i+1]+.114*data.data[i+2];let v=Math.max(0,Math.min(255,(val-105)*2+125));data.data[i]=data.data[i+1]=data.data[i+2]=v;}
   ctx.putImageData(data,0,0);
   const result=await worker.recognize(canvas),txt=result.data.text||'';readings.push(job.name+': '+txt.trim());
   for(const line of txt.split(/\n/)){
    if(/(?:trip|denn[ií]|\d{1,2}:\d{2}|\d{1,2}[.\/]\d{1,2}[.\/]20\d{2})/i.test(line)&&!/\bkm\b/i.test(line))continue;
    const nums=[...line.matchAll(/(?<!\d)(\d(?:[ \.]?\d){4,6})(?!\d)/g)];
    for(const match of nums){const n=Number(match[1].replace(/\D/g,''));if(n>=10000&&n<=9999999){let score=(/\bkm\b/i.test(line)?5:0)+(job.name==='dolní část displeje'?1:0)+(n>=100000?1:0);candidates.push({n,score,line:line.trim()})}}
   }
  }
 }finally{await worker.terminate();img.close?.()}
 const grouped=new Map();for(const c of candidates){const old=grouped.get(c.n)||{n:c.n,score:0,count:0};old.score+=c.score+1;old.count++;grouped.set(c.n,old)}
 const sorted=[...grouped.values()].sort((a,b)=>b.score-a.score||b.count-a.count);
 const best=sorted[0];const runner=sorted[1];
 // Nenabízej automatické vyplnění při nejednoznačném odečtu.
 const reliable=!!best&&(best.count>=2||best.score>=6)&&(!runner||best.score>=runner.score+3);
 return {km:reliable?String(best.n):'',suggestion:best?String(best.n):'',reliable,text:readings.join('\n\n')};
}
async function ensurePdf(){if(!pdfReady){await injectScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';pdfReady=true}}
async function readPdf(file,onProgress){await ensurePdf();const d=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise;let text='';for(let i=1;i<=Math.min(d.numPages,8);i++){onProgress(`Čtu PDF: stránka ${i} z ${Math.min(d.numPages,8)}`);const pg=await d.getPage(i),tc=await pg.getTextContent();let pageText=tc.items.map(x=>x.str).join(' ');if(pageText.trim().length<25){onProgress(`Rozpoznávám sken PDF: stránka ${i}`);const viewport=pg.getViewport({scale:2});const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;await pg.render({canvasContext:canvas.getContext('2d'),viewport}).promise;pageText=await ocrImage(canvas,onProgress)}text+=pageText+'\n'}return text}
let sheetReady=false;
async function readSpreadsheet(file,onProgress){if(!sheetReady){await injectScript('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js');sheetReady=true}onProgress('Čtu tabulky Excelu…');const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true,cellText:true});return wb.SheetNames.slice(0,12).map(name=>{const sheet=wb.Sheets[name];return 'List '+name+'\n'+XLSX.utils.sheet_to_csv(sheet,{blankrows:false})}).join('\n\n').slice(0,100000)}
async function readDocument(file,onProgress){const n=file.name.toLowerCase();if(n.endsWith('.pdf'))return readPdf(file,onProgress);if(/\.(xlsx|xls|xlsm|csv)$/.test(n))return readSpreadsheet(file,onProgress);if(file.type.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/.test(n))return ocrImage(file,onProgress);throw Error('Nepodporovaný formát. Nahraj PDF, Excel, CSV nebo obrázek.')}
function extractFields(text){const lines=text.split(/\n/).map(x=>x.trim()).filter(Boolean);const m=text.match(/\b([0-3]?\d)[.\/\-]\s*([01]?\d)[.\/\-]\s*(20\d\d)\b/);let date=m?`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`:'';
const prices=[...text.matchAll(/(?:celkem\s*k\s*úhradě|k\s*úhradě|celkem|total|částka)[^\d\n]{0,25}([\d\s.,]{2,16})\s*(?:Kč|CZK)?/gi)].map(m=>m[1]).filter(Boolean);
const amount=x=>{let t=x.replace(/\s/g,'').replace(/[^\d,.]/g,'');if(t.includes(','))t=t.replace(/\./g,'').replace(',','.');else if((t.match(/\./g)||[]).length>1)t=t.replace(/\./g,'');return parseFloat(t)};
let price=prices.map(amount).find(x=>Number.isFinite(x)&&x>0&&x<10000000);
const kmMatch=text.match(/(?:tachometr|stav\s*km|najeto|kilometr(?:ů|y)?|odo(?:meter)?)\D{0,22}(\d[\d\s]{1,8})\s*(?:km)?/i);
return {date,price:price||'',km:kmMatch?kmMatch[1].replace(/\s/g,''):'',title:lines.find(l=>/výměna|olej|filtr|brzdy|servis|oprava|rozvody/i.test(l))?.slice(0,100)||'',note:text.trim()};}
function setupPhotoTools(old,isOdo){const inp=$('photo-upload'),canvas=$('redact-canvas'),wrap=$('redact-tools'),ctx=canvas.getContext('2d');let image=null,rects=[],begin=null,removeOld=false;
function repaint(){if(!image)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);ctx.fillStyle='#000';rects.forEach(r=>ctx.fillRect(r.x,r.y,r.w,r.h))}
function point(ev){const b=canvas.getBoundingClientRect();return {x:(ev.clientX-b.left)*canvas.width/b.width,y:(ev.clientY-b.top)*canvas.height/b.height}}
canvas.onpointerdown=e=>{if(!image)return;begin=point(e);canvas.setPointerCapture(e.pointerId)};
canvas.onpointerup=e=>{if(!begin)return;const end=point(e),r={x:Math.min(begin.x,end.x),y:Math.min(begin.y,end.y),w:Math.abs(begin.x-end.x),h:Math.abs(begin.y-end.y)};if(r.w>6&&r.h>6)rects.push(r);begin=null;repaint()};
$('redact-undo').onclick=()=>{rects.pop();repaint()};$('redact-reset').onclick=()=>{rects=[];repaint()};
$('remove-attachment').onclick=()=>{removeOld=true;inp.value='';image=null;rects=[];wrap.hidden=true;$('attached').textContent='Příloha bude odstraněna při uložení.'};
async function loadImage(file){const u=URL.createObjectURL(file);try{const im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=u});image=im;let scale=Math.min(1,1400/im.width,1400/im.height);canvas.width=Math.max(1,Math.round(im.width*scale));canvas.height=Math.max(1,Math.round(im.height*scale));rects=[];wrap.hidden=false;repaint()}finally{URL.revokeObjectURL(u)}}
inp.onchange=async()=>{const f=inp.files[0];if(!f)return;removeOld=false;if(f.type.startsWith('image/')){try{await loadImage(f)}catch{notice('Fotografii nelze otevřít')}}else{image=null;wrap.hidden=true} $('attached').textContent='Nová příloha: '+f.name};
$('run-ocr').onclick=async()=>{const f=inp.files[0];if(!f){notice('Nejdříve přilož fotografii, PDF nebo Excel');return}const btn=$('run-ocr');btn.disabled=true;try{$('ocr-progress').textContent='Načítám čtení dokladů…';if(isOdo && f.type.startsWith('image/')){const out=await readOdometer(f,s=>$('ocr-progress').textContent=s);$('ocr-text').value=out.text;if(out.km)$('rec-km').value=out.km;$('ocr-progress').textContent=out.reliable?'Nalezeno '+Number(out.km).toLocaleString('cs-CZ')+' km. Prosím ověř podle fotografie.':(out.suggestion?'Nejistý odečet ('+Number(out.suggestion).toLocaleString('cs-CZ')+' km). Zkontroluj fotografii a vyplň km ručně.':'Kilometry nebyly spolehlivě rozpoznány. Zadej je podle fotografie ručně.');}else{const txt=await readDocument(f,s=>$('ocr-progress').textContent=s);const data=extractFields(txt);$('ocr-text').value=txt;if(data.date)$('rec-date').value=data.date;if(data.price)$('rec-price')&&($('rec-price').value=data.price);if(data.km)$('rec-km').value=data.km;if(data.title)$('rec-title').value=data.title;$('ocr-progress').textContent='Rozpoznáno. Zkontroluj a uprav pole i text.';}}catch(e){$('ocr-progress').textContent='Chyba: '+e.message}finally{btn.disabled=false}};
return {async attachment(){const file=inp.files[0];if(!file)return {fileData:removeOld?'':old.fileData||'',fileName:removeOld?'':old.fileName||''};if(image){const type='image/jpeg',fileData=canvas.toDataURL(type,.83);if(fileData.length>4*1024*1024)throw Error('Fotografie je moc velká; pořiď menší snímek.');return {fileData,fileName:file.name.replace(/\.[^.]+$/, '')+'-upraveno.jpg'}}if(file.size>2.2*1024*1024)throw Error('Příloha je moc velká (max. 2,2 MB).');const fileData=await new Promise((ok,no)=>{let r=new FileReader();r.onload=()=>ok(r.result);r.onerror=no;r.readAsDataURL(file)});return{fileData,fileName:file.name}}};
}
function openRecord(id,type='service'){
if(!db.cars.length){notice('Nejdřív přidej auto');showTab('overview');return}
const old=db.records.find(r=>r.id===id)||{},isOdo=(old.type||type)==='odo';const cs=db.cars.map(c=>`<option value="${html(c.id)}" ${(old.carId||activeCar)===c.id?'selected':''}>${html(c.brand+' '+c.model)}</option>`).join('');
const content=`<label>Auto<select name="carId">${cs}</select></label><label>Datum<input id="rec-date" type="date" name="date" required value="${html(old.date||today())}"></label><label>Název záznamu<input id="rec-title" name="title" required value="${html(old.title||(isOdo?'Stav tachometru':''))}" placeholder="Výměna oleje, brzdy…"></label><label>Kilometry<input id="rec-km" name="km" type="number" min="0" inputmode="numeric" value="${html(old.km||'')}"></label>${isOdo?'':`<label>Cena v Kč<input id="rec-price" name="price" type="number" step="0.01" min="0" value="${html(old.price||'')}"></label>`}<label>Poznámky<textarea name="note" rows="3">${html(old.note||'')}</textarea></label><label>Vybrat z telefonu (galerie, PDF, Excel, CSV)<input name="photo" id="photo-upload" type="file" accept="image/*,.pdf,.xlsx,.xls,.xlsm,.csv,application/pdf"></label><button type="button" id="run-ocr" class="secondary read-btn">🔎 Přečíst fakturu / tachometr</button><div id="ocr-progress" aria-live="polite">Čtení spustíš po nahrání. Vyžaduje internet při načtení OCR.</div><label>Rozpoznaný text – můžeš vymazat či opravit jednotlivé údaje<textarea id="ocr-text" name="ocrText" rows="6" placeholder="Text rozpoznaný z faktury">${html(old.ocrText||'')}</textarea></label><div id="redact-tools" hidden><p><b>Začernění údajů na fotografii</b></p><p class="hint">Prstem táhni přes část faktury, kterou chceš skrýt. Uloží se pouze upravená fotografie. Původní snímek není součástí zálohy.</p><canvas id="redact-canvas" style="width:100%;height:auto;border:1px solid #b9c6d7;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="redact-undo" class="secondary">↶ Vrátit poslední</button><button type="button" id="redact-reset" class="ghost">Zrušit začernění</button></div></div><div class="actions"><button type="button" class="ghost" id="remove-attachment">🗑 Odebrat přílohu</button></div><div id="attached" class="note">${old.fileData?`Uložená příloha: <a href="${old.fileData}" download="${html(old.fileName||'priloha')}">Otevřít / stáhnout</a>`:'Bez přílohy'}</div><p class="warning">OCR může údaje přečíst nesprávně, zejména ceny a kilometry. Před uložením je potvrď. Začernění přímo v příloze platí jen pro fotografie. Z PDF/Excelu lze odstranit údaje z přepisu, ale původní dokument zůstane beze změny. Citlivé soubory před přiložením uprav mimo aplikaci.</p>`;
let tools;
modal(id?'Upravit záznam':(isOdo?'Nový stav tachometru':'Nový servisní záznam'),content,async f=>{try{const attachment=await tools.attachment();const r={id:id||uid(),type:isOdo?'odo':'service',carId:f.get('carId'),date:f.get('date'),title:f.get('title').trim(),km:f.get('km'),price:isOdo?0:f.get('price'),note:f.get('note').trim(),ocrText:f.get('ocrText').trim(),...attachment};const proposed=id?db.records.map(x=>x.id===id?r:x):[...db.records,r];const before=db.records;db.records=proposed;if(save()){close();notice('Záznam uložen')}else db.records=before}catch(e){alert(e.message)}},id?()=>{db.records=db.records.filter(r=>r.id!==id);save()}:null);
tools=setupPhotoTools(old,isOdo);
}
$('add-invoice').onclick=()=>openRecord(null,'service');$('add-service').onclick=()=>openRecord(null,'service');$('add-odo').onclick=()=>openRecord(null,'odo');$('history-add').onclick=()=>openRecord(null,'service');
$('export').onclick=()=>{const blob=new Blob([JSON.stringify({format:'mojeauto-v1',...db},null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='moje-auto-zaloha-'+today()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),3000)};
$('import-button').onclick=()=>$('import-file').click();$('import-file').onchange=async e=>{try{const x=JSON.parse(await e.target.files[0].text());if(!Array.isArray(x.cars)||!Array.isArray(x.records))throw Error('Nesprávný formát');if(confirm('Obnovit zálohu? Aktuální záznamy budou nahrazeny.')){db={cars:x.cars,records:x.records};if(save()){activeCar=null;render();notice('Záloha obnovena')}}}catch(err){alert('Neplatná záloha: '+err.message)}e.target.value=''};
// Funkce cloudu v této offline mobilní verzi není aktivní; nedovolujeme uložit klíče bez připojení.
$('settings').querySelector('h2').textContent='Nastavení a záloha';$('settings').querySelector('.panel').style.display='none';
render();if(activeCar)attachRecords();
if('serviceWorker'in navigator && location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
