window.MOJE_AUTO_BUILD = 7;
