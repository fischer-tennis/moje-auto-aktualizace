'use strict';
const $=id=>document.getElementById(id), key='mojeauto_v1';
let db={cars:[],records:[]}, editing=null, activeCar=null;
try{const x=JSON.parse(localStorage.getItem(key)||'null');if(x&&Array.isArray(x.cars)&&Array.isArray(x.records))db=x}catch{}
const save=()=>{try{localStorage.setItem(key,JSON.stringify(db));return true}catch(e){alert('Nepodařilo se uložit. Úložiště telefonu může být plné. Proveď zálohu a zmenši fotografie.');return false}};
const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random());
const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>Number(n||0).toLocaleString('cs-CZ',{style:'currency',currency:'CZK',maximumFractionDigits:0});
const date=d=>d?new Date(d+'T12:00:00').toLocaleDateString('cs-CZ'):'—';
function notice(s){$('toast').textContent=s;setTimeout(()=>$('toast').textContent='',3300)}
function showTab(t){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('active',e.id===t));document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('active',e.dataset.view===t));render()}
document.querySelectorAll('.tab').forEach(e=>e.addEventListener('click',()=>showTab(e.dataset.view)));
const carName=id=>{const c=db.cars.find(x=>x.id===id);return c?`${c.brand} ${c.model}`:'Neznámé auto'};
function render(){const cars=$('car-list');cars.innerHTML=db.cars.length?db.cars.map(c=>`<button class="car ${c.id===activeCar?'selected':''}" data-car="${html(c.id)}"><div><b>🚘 ${html(c.brand)} ${html(c.model)}</b><small>${html(c.plate||'Bez SPZ')} · ${html(c.year||'Rok neuveden')}</small></div><span>✎</span></button>`).join(''):'<div class="panel">Zatím nemáš uložené žádné auto. Začni tlačítkem „Přidat auto“.</div>';
cars.querySelectorAll('[data-car]').forEach(b=>b.onclick=()=>{activeCar=b.dataset.car;render();});
if(!db.cars.some(c=>c.id===activeCar))activeCar=db.cars[0]?.id||null;
$('overview-details').hidden=!activeCar;
if(activeCar){const rs=db.records.filter(r=>r.carId===activeCar);const odo=rs.filter(r=>Number(r.km)>0).sort((a,b)=>Number(b.km)-Number(a.km))[0];$('stats').innerHTML=`<div class="stat"><small>Vybrané auto</small><strong>${html(carName(activeCar))}</strong><button class="secondary" id="edit-car">Upravit auto</button></div><div class="stat"><small>Poslední stav tachometru</small><strong>${odo?Number(odo.km).toLocaleString('cs-CZ')+' km':'—'}</strong></div><div class="stat"><small>Celkové servisní náklady</small><strong>${money(rs.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</strong></div>`;$('edit-car').onclick=()=>openCar(activeCar);$('recent').innerHTML=listRecords(rs.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5));}
$('history-car').innerHTML='<option value="all">Všechna auta</option>'+db.cars.map(c=>`<option value="${html(c.id)}">${html(c.brand+' '+c.model)}</option>`).join('');const selected=$('history-car').dataset.selected||'all';$('history-car').value=[...$('history-car').options].some(o=>o.value===selected)?selected:'all';renderHistory();renderCosts();attachRecords();}
function listRecords(rows){if(!rows.length)return'<p class="note">Zatím žádné záznamy.</p>';return rows.map(r=>`<button class="record" data-rec="${html(r.id)}"><div><b>${r.type==='odo'?'📸':'🔧'} ${html(r.title)}</b><small>${html(carName(r.carId))} · ${date(r.date)} ${r.km?'· '+Number(r.km).toLocaleString('cs-CZ')+' km':''}</small></div><b>${r.type==='service'?money(r.price):'›'}</b></button>`).join('')}
function attachRecords(){document.querySelectorAll('[data-rec]').forEach(b=>b.onclick=()=>openRecord(b.dataset.rec))}
function renderHistory(){let rows=db.records;let car=$('history-car').value;if(car!=='all')rows=rows.filter(r=>r.carId===car);let q=$('history-search').value.trim().toLowerCase();if(q)rows=rows.filter(r=>(r.title+' '+r.note+' '+carName(r.carId)).toLowerCase().includes(q));$('history-list').innerHTML=listRecords(rows.slice().sort((a,b)=>b.date.localeCompare(a.date)));attachRecords()}
function renderCosts(){let sum=db.records.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0);$('costs-body').innerHTML=`<div class="stat"><small>Celkové servisní náklady</small><strong>${money(sum)}</strong></div>`+db.cars.map(c=>`<div class="record"><b>${html(c.brand+' '+c.model)}</b><b>${money(db.records.filter(r=>r.carId===c.id&&r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</b></div>`).join('')}
$('history-car').onchange=()=>{$('history-car').dataset.selected=$('history-car').value;renderHistory()};$('history-search').oninput=renderHistory;
function modal(title,body,onSubmit,onDelete){$('editor-title').textContent=title;$('editor-fields').innerHTML=body;$('editor').showModal();$('editor-form').onsubmit=e=>{e.preventDefault();onSubmit(new FormData(e.currentTarget))};$('delete-item').hidden=!onDelete;$('delete-item').onclick=()=>{if(confirm('Opravdu smazat?')){onDelete();$('editor').close();render()}}}
function close(){ $('editor').close();render() }$('close-dialog').onclick=close;$('cancel-dialog').onclick=close;
function openCar(id){const c=db.cars.find(x=>x.id===id)||{};modal(id?'Upravit auto':'Přidat auto',`<label>Značka<input name="brand" required value="${html(c.brand||'')}"></label><label>Model<input name="model" required value="${html(c.model||'')}"></label><label>SPZ<input name="plate" value="${html(c.plate||'')}"></label><label>Rok výroby<input name="year" inputmode="numeric" value="${html(c.year||'')}"></label><label>VIN (volitelné)<input name="vin" value="${html(c.vin||'')}"></label>`,f=>{const x={id:id||uid(),brand:f.get('brand').trim(),model:f.get('model').trim(),plate:f.get('plate').trim(),year:f.get('year').trim(),vin:f.get('vin').trim()};if(id)db.cars=db.cars.map(z=>z.id===id?x:z);else db.cars.push(x);activeCar=x.id;if(save())close()},id?()=>{db.cars=db.cars.filter(c=>c.id!==id);db.records=db.records.filter(r=>r.carId!==id);save()}:null)}
$('add-car').onclick=()=>openCar();
const today=()=>new Date().toLocaleDateString('sv-SE');
// OCR běží přímo v prohlížeči, bez odesílání fotografie na server.
const injectScript=(url)=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=url;s.onload=ok;s.onerror=()=>no(Error('Nepodařilo se načíst OCR knihovnu. Zkontroluj internet.'));document.head.appendChild(s)});
let ocrReady=false,pdfReady=false;
async function ocrImage(file,onProgress){if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}const worker=await Tesseract.createWorker('ces+eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení textu: '+Math.round((e.progress||0)*100)+' %')}});try{const r=await worker.recognize(file);return r.data.text}finally{await worker.terminate()}}
// Tachometr V6.1: světlé číslice na tmavém displeji převedeme na černé číslice
// na bílém podkladu. Když automatika selže, lze vybrat prstem jen oblast kilometrů.
function odometerCandidates(text,job,confidence=0){
 const rows=String(text||'').replace(/[|]/g,'1').split(/\r?\n/).map(s=>s.trim()).filter(Boolean),found=[];
 for(let i=0;i<rows.length;i++){
  let line=rows[i];
  // I / l uvnitř čísla bývá na displeji OCR často zaměněné za jedničku.
  line=line.replace(/(?<=[\d\s])[Il](?=\d)/g,'1').replace(/(?<=\d)[Il](?=\s|$)/g,'1').replace(/(?<=\d)[OoQ](?=\d)/g,'0');
  const hasKm=/\b(?:km|kms|odo|odometer)\b/i.test(line)||/\bkm\b/i.test(rows[i-1]||'')||/\bkm\b/i.test(rows[i+1]||'');
  const hasTrip=/\b(?:trip|denn[ií]|daily)\b/i.test(line);
  // Datum, hodiny a denní počítadlo nesmějí soutěžit s celkovými kilometry.
  const cleaned=line
   .replace(/\b[0-3]?\d[.\/-][01]?\d[.\/-](?:20)?\d{2,4}\b/g,' ')
   .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g,' ')
   .replace(/\b(?:trip|denn[ií]|daily)\s*[:=]?\s*\d+(?:[.,]\d+)?\b/gi,' ');
  for(const match of cleaned.matchAll(/(?<!\d)\d(?:[ \u00a0\u202f.]?\d){2,8}(?!\d)/g)){
   const digits=match[0].replace(/\D/g,'');
   if(digits.length<3||digits.length>7)continue;
   if(!hasKm&&!job.manual&&Number(digits)<10000)continue;
   if(hasTrip&&!hasKm&&!job.manual)continue;
   const n=Number(digits);
   if(n<1||n>9999999)continue;
   const weight=job.weight+(hasKm?7:0)+(digits.length>=5?2:0)+(Math.min(4,Math.max(0,confidence)/25));
   found.push({n,weight,conf:confidence,hasKm,manual:!!job.manual,focus:!!job.focus});
  }
 }
 return found;
}
function odometerImage(img,box,mode='bright'){
 const width=img.width,height=img.height;
 let [x,y,w,h]=box;
 x=Math.max(0,Math.min(.99,x));y=Math.max(0,Math.min(.99,y));
 w=Math.max(.015,Math.min(1-x,w));h=Math.max(.015,Math.min(1-y,h));
 const sx=Math.floor(x*width),sy=Math.floor(y*height),sw=Math.max(1,Math.floor(w*width)),sh=Math.max(1,Math.floor(h*height));
 const factor=Math.min(7,2200/sw,1600/sh);
 const canvas=document.createElement('canvas');
 canvas.width=Math.max(1,Math.round(sw*factor));canvas.height=Math.max(1,Math.round(sh*factor));
 const ctx=canvas.getContext('2d',{willReadFrequently:true});
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
 ctx.drawImage(img,sx,sy,sw,sh,0,0,canvas.width,canvas.height);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),a=pixels.data;
 const hist=new Uint32Array(256);
 for(let i=0;i<a.length;i+=4){const lum=Math.round(a[i]*.299+a[i+1]*.587+a[i+2]*.114);hist[lum]++}
 function percentile(p){let target=canvas.width*canvas.height*p,acc=0;for(let i=0;i<256;i++){acc+=hist[i];if(acc>=target)return i}return 255}
 const middle=percentile(.5),top=percentile(.9),bottom=percentile(.12);
 const isLightOnDark=middle<149;
 let threshold=isLightOnDark?Math.min(215,Math.max(91,top-5)):Math.min(205,Math.max(55,bottom+18));
 if(mode==='bright-soft')threshold+=isLightOnDark?-15:15;
 for(let i=0;i<a.length;i+=4){const lum=a[i]*.299+a[i+1]*.587+a[i+2]*.114;
  let v;if(mode==='bright'||mode==='bright-soft')v=isLightOnDark?(lum>=threshold?0:255):(lum<threshold?0:255);
  else {const normalized=Math.max(0,Math.min(255,(lum-bottom)*255/Math.max(20,top-bottom)));v=isLightOnDark?255-normalized:normalized}
  a[i]=a[i+1]=a[i+2]=v;a[i+3]=255;
 }
 ctx.putImageData(pixels,0,0);return canvas;
}
async function readOdometer(file,onProgress,selectedBox=null){
 if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}
 const img=await createImageBitmap(file),readings=[],found=[];
 const manual=!!selectedBox;
 const jobs=manual?[
  {name:'označená oblast – číslice',box:selectedBox,mode:'bright',psm:6,onlyDigits:true,weight:9,manual:true,focus:true},
  {name:'označená oblast – jemnější práh',box:selectedBox,mode:'bright-soft',psm:7,onlyDigits:true,weight:8,manual:true,focus:true}
 ]:[
  {name:'celkové kilometry – detail',box:[.262,.545,.245,.125],mode:'bright',psm:6,onlyDigits:true,weight:7,focus:true},
  {name:'celkové kilometry – jiný kontrast',box:[.262,.545,.245,.125],mode:'bright-soft',psm:7,onlyDigits:true,weight:7,focus:true},
  {name:'dolní displej s označením km',box:[.12,.42,.77,.39],mode:'bright',psm:11,onlyDigits:false,weight:3},
  {name:'celý středový displej',box:[.15,.17,.7,.68],mode:'contrast',psm:11,onlyDigits:false,weight:1}
 ];
 let worker;
 try{
  worker=await Tesseract.createWorker('eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení tachometru: '+Math.round((e.progress||0)*100)+' %')}});
  for(const job of jobs){
   onProgress('Hledám kilometry: '+job.name+'…');
   await worker.setParameters({tessedit_pageseg_mode:job.psm,tessedit_char_whitelist:job.onlyDigits?'0123456789 ':''});
   const canvas=odometerImage(img,job.box,job.mode);
   const result=await worker.recognize(canvas),txt=String(result.data.text||'').trim();
   const conf=Number(result.data.confidence)||0;
   readings.push(job.name+': '+(txt||'(nepřečteno)'));
   found.push(...odometerCandidates(txt,job,conf));
  }
 }finally{if(worker)await worker.terminate();img.close?.()}
 const grouped=new Map();
 for(const c of found){let g=grouped.get(c.n);if(!g){g={n:c.n,score:0,hits:0,conf:0,hasKm:false,manual:false,focus:false};grouped.set(c.n,g)}
  g.score+=c.weight;g.hits++;g.conf=Math.max(g.conf,c.conf);g.hasKm ||=c.hasKm;g.manual ||=c.manual;g.focus ||=c.focus;
 }
 const ranking=[...grouped.values()].sort((a,b)=>b.score-a.score||b.hits-a.hits);
 const best=ranking[0],second=ranking[1];
 const consistent=!!best&&(!second||best.score>=second.score+5);
 const reliable=!!best&&consistent&&(
   best.hits>=2 || best.hasKm&&best.conf>=50 || best.focus&&best.conf>=83&&String(best.n).length>=5
 );
 return {km:reliable?String(best.n):'',suggestion:best?String(best.n):'',reliable,
  text:readings.join('\n\n'),alternatives:ranking.slice(1,3).map(r=>r.n)};
}
async function ensurePdf(){if(!pdfReady){await injectScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';pdfReady=true}}
async function readPdf(file,onProgress){await ensurePdf();const d=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise;let text='';for(let i=1;i<=Math.min(d.numPages,8);i++){onProgress(`Čtu PDF: stránka ${i} z ${Math.min(d.numPages,8)}`);const pg=await d.getPage(i),tc=await pg.getTextContent();let pageText=tc.items.map(x=>x.str).join(' ');if(pageText.trim().length<25){onProgress(`Rozpoznávám sken PDF: stránka ${i}`);const viewport=pg.getViewport({scale:2});const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;await pg.render({canvasContext:canvas.getContext('2d'),viewport}).promise;pageText=await ocrImage(canvas,onProgress)}text+=pageText+'\n'}return text}
let sheetReady=false;
async function readSpreadsheet(file,onProgress){if(!sheetReady){await injectScript('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js');sheetReady=true}onProgress('Čtu tabulky Excelu…');const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true,cellText:true});return wb.SheetNames.slice(0,12).map(name=>{const sheet=wb.Sheets[name];return 'List '+name+'\n'+XLSX.utils.sheet_to_csv(sheet,{blankrows:false})}).join('\n\n').slice(0,100000)}
async function readDocument(file,onProgress){const n=file.name.toLowerCase();if(n.endsWith('.pdf'))return readPdf(file,onProgress);if(/\.(xlsx|xls|xlsm|csv)$/.test(n))return readSpreadsheet(file,onProgress);if(file.type.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/.test(n))return ocrImage(file,onProgress);throw Error('Nepodporovaný formát. Nahraj PDF, Excel, CSV nebo obrázek.')}
function extractFields(text){const lines=text.split(/\n/).map(x=>x.trim()).filter(Boolean);const m=text.match(/\b([0-3]?\d)[.\/\-]\s*([01]?\d)[.\/\-]\s*(20\d\d)\b/);let date=m?`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`:'';
const prices=[...text.matchAll(/(?:celkem\s*k\s*úhradě|k\s*úhradě|celkem|total|částka)[^\d\n]{0,25}([\d\s.,]{2,16})\s*(?:Kč|CZK)?/gi)].map(m=>m[1]).filter(Boolean);
const amount=x=>{let t=x.replace(/\s/g,'').replace(/[^\d,.]/g,'');if(t.includes(','))t=t.replace(/\./g,'').replace(',','.');else if((t.match(/\./g)||[]).length>1)t=t.replace(/\./g,'');return parseFloat(t)};
let price=prices.map(amount).find(x=>Number.isFinite(x)&&x>0&&x<10000000);
const kmMatch=text.match(/(?:tachometr|stav\s*km|najeto|kilometr(?:ů|y)?|odo(?:meter)?)\D{0,22}(\d[\d\s]{1,8})\s*(?:km)?/i);
return {date,price:price||'',km:kmMatch?kmMatch[1].replace(/\s/g,''):'',title:lines.find(l=>/výměna|olej|filtr|brzdy|servis|oprava|rozvody/i.test(l))?.slice(0,100)||'',note:text.trim()};}
function setupPhotoTools(old,isOdo){
 const inp=$('photo-upload'),canvas=$('redact-canvas'),wrap=$('redact-tools'),ctx=canvas.getContext('2d');
 const odoCanvas=isOdo?$('odo-select-canvas'):null,odoWrap=isOdo?$('odo-select-tools'):null;
 let image=null,rects=[],begin=null,removeOld=false;
 let odoView=[0,.30,1,.70],odoRect=null,odoBegin=null;
 function repaint(){if(!image)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);ctx.fillStyle='#000';rects.forEach(r=>ctx.fillRect(r.x,r.y,r.w,r.h))}
 function point(ev,c){const b=c.getBoundingClientRect();return{x:(ev.clientX-b.left)*c.width/b.width,y:(ev.clientY-b.top)*c.height/b.height}}
 // Začernění faktury je nezávislé na výběru oblasti pro OCR tachometru.
 canvas.onpointerdown=e=>{if(!image)return;begin=point(e,canvas);canvas.setPointerCapture(e.pointerId)};
 canvas.onpointerup=e=>{if(!begin)return;const end=point(e,canvas),r={x:Math.min(begin.x,end.x),y:Math.min(begin.y,end.y),w:Math.abs(begin.x-end.x),h:Math.abs(begin.y-end.y)};if(r.w>6&&r.h>6)rects.push(r);begin=null;repaint()};
 $('redact-undo').onclick=()=>{rects.pop();repaint()};$('redact-reset').onclick=()=>{rects=[];repaint()};
 function repaintOdo(){if(!image||!odoCanvas)return;
  const c=odoCanvas.getContext('2d'),[x,y,w,h]=odoView;
  const iw=image.naturalWidth||image.width,ih=image.naturalHeight||image.height;
  c.drawImage(image,iw*x,ih*y,iw*w,ih*h,0,0,odoCanvas.width,odoCanvas.height);
  const r=odoRect||odoBegin;
  if(r){c.fillStyle='rgba(36,153,230,.18)';c.strokeStyle='#27d5ff';c.lineWidth=4;
   const a=(r.x-x)/w*odoCanvas.width,b=(r.y-y)/h*odoCanvas.height,d=r.w/w*odoCanvas.width,e=r.h/h*odoCanvas.height;
   c.fillRect(a,b,d,e);c.strokeRect(a,b,d,e)}
 }
 function odoPoint(ev){const v=point(ev,odoCanvas),[x,y,w,h]=odoView;return{x:x+v.x/odoCanvas.width*w,y:y+v.y/odoCanvas.height*h}}
 function odoSelection(start,end){const [x,y,w,h]=odoView;const l=Math.max(x,Math.min(start.x,end.x)),t=Math.max(y,Math.min(start.y,end.y));return{x:l,y:t,w:Math.min(x+w,Math.max(start.x,end.x))-l,h:Math.min(y+h,Math.max(start.y,end.y))-t}}
 if(odoCanvas){
  odoCanvas.onpointerdown=e=>{if(!image)return;odoCanvas.setPointerCapture(e.pointerId);odoBegin={start:odoPoint(e),current:odoPoint(e)};odoRect=null};
  odoCanvas.onpointermove=e=>{if(!odoBegin)return;odoBegin.current=odoPoint(e);const temp=odoSelection(odoBegin.start,odoBegin.current);odoRect=temp;repaintOdo()};
  odoCanvas.onpointerup=e=>{if(!odoBegin)return;const r=odoSelection(odoBegin.start,odoPoint(e));odoBegin=null;odoRect=r.w>=.018&&r.h>=.012?r:null;$('odo-read-selected').disabled=!odoRect;repaintOdo()};
  odoCanvas.onpointercancel=()=>{odoBegin=null;repaintOdo()};
  $('odo-view-toggle').onclick=()=>{odoView=odoView[1]===0?[0,.30,1,.70]:[0,0,1,1];odoRect=null;$('odo-read-selected').disabled=true;$('odo-view-toggle').textContent=odoView[1]===0?'Zobrazit spodní část':'Zobrazit celý snímek';repaintOdo()};
 }
 $('remove-attachment').onclick=()=>{removeOld=true;inp.value='';image=null;rects=[];odoRect=null;wrap.hidden=true;if(odoWrap)odoWrap.hidden=true;$('attached').textContent='Příloha bude odstraněna při uložení.'};
 async function loadImage(file){const u=URL.createObjectURL(file);try{const im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=u});image=im;
  const scale=Math.min(1,1400/im.width,1400/im.height);canvas.width=Math.max(1,Math.round(im.width*scale));canvas.height=Math.max(1,Math.round(im.height*scale));rects=[];wrap.hidden=isOdo;repaint();
  if(odoCanvas){odoView=[0,.30,1,.70];odoRect=null;odoCanvas.width=Math.min(1200,im.width);odoCanvas.height=Math.max(1,Math.round(odoCanvas.width*im.height*.70/im.width));odoWrap.hidden=false;$('odo-read-selected').disabled=true;$('odo-view-toggle').textContent='Zobrazit celý snímek';repaintOdo()}
 }finally{URL.revokeObjectURL(u)}}
 inp.onchange=async()=>{const f=inp.files[0];if(!f)return;removeOld=false;const isImg=f.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(f.name);if(isImg){try{await loadImage(f)}catch{notice('Fotografii nelze otevřít')}}else{image=null;wrap.hidden=true;if(odoWrap)odoWrap.hidden=true} $('attached').textContent='Nová příloha: '+f.name;if(isOdo&&isImg&&image)doOCR();};
 async function doOCR(box=null){const f=inp.files[0];if(!f){notice('Nejdříve přilož fotografii, PDF nebo Excel');return}
  const btn=$('run-ocr'),selectedBtn=isOdo?$('odo-read-selected'):null;btn.disabled=true;if(selectedBtn)selectedBtn.disabled=true;
  try{$('ocr-progress').textContent='Načítám čtení dokladů…';
   const isImg=f.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(f.name);
   if(isOdo&&isImg){const out=await readOdometer(f,s=>$('ocr-progress').textContent=s,box);
    $('ocr-text').value=out.text;
    if(out.km)$('rec-km').value=out.km;
    $('ocr-progress').textContent=out.reliable?'✅ Odečteno '+Number(out.km).toLocaleString('cs-CZ')+' km. Zkontroluj číslo na fotografii před uložením.':
      (out.suggestion?'⚠️ Nejistý odečet: možná '+Number(out.suggestion).toLocaleString('cs-CZ')+' km. Zkontroluj a doplň počet km ručně.':'⚠️ Kilometry se nepodařilo bezpečně určit. Označ prstem na fotografii jen číslice a klikni na „Přečíst označené km“.');
   }else{const txt=await readDocument(f,s=>$('ocr-progress').textContent=s),data=extractFields(txt);$('ocr-text').value=txt;
    if(data.date)$('rec-date').value=data.date;if(data.price&&$('rec-price'))$('rec-price').value=data.price;if(data.km)$('rec-km').value=data.km;if(data.title)$('rec-title').value=data.title;
    $('ocr-progress').textContent='Rozpoznáno. Zkontroluj a uprav pole i text.'}
  }catch(e){$('ocr-progress').textContent='Chyba: '+e.message}finally{btn.disabled=false;if(selectedBtn)selectedBtn.disabled=!odoRect}
 }
 $('run-ocr').onclick=()=>doOCR();
 if(isOdo)$('odo-read-selected').onclick=()=>{
  if(!odoRect)return;
  // Výběr mírně rozšíříme, aby nedošlo k odříznutí krajních číslic.
  const x=Math.max(0,odoRect.x-.014),y=Math.max(0,odoRect.y-.013);
  doOCR([x,y,Math.min(1-x,odoRect.w+.028),Math.min(1-y,odoRect.h+.026)]);
 };
 return {async attachment(){const file=inp.files[0];if(!file)return {fileData:removeOld?'':old.fileData||'',fileName:removeOld?'':old.fileName||''};if(image){const fileData=canvas.toDataURL('image/jpeg',.83);if(fileData.length>4*1024*1024)throw Error('Fotografie je moc velká; pořiď menší snímek.');return {fileData,fileName:file.name.replace(/\.[^.]+$/, '')+'-upraveno.jpg'}}if(file.size>2.2*1024*1024)throw Error('Příloha je moc velká (max. 2,2 MB).');const fileData=await new Promise((ok,no)=>{let r=new FileReader();r.onload=()=>ok(r.result);r.onerror=no;r.readAsDataURL(file)});return{fileData,fileName:file.name}}};
}
function openRecord(id,type='service'){
if(!db.cars.length){notice('Nejdřív přidej auto');showTab('overview');return}
const old=db.records.find(r=>r.id===id)||{},isOdo=(old.type||type)==='odo';const cs=db.cars.map(c=>`<option value="${html(c.id)}" ${(old.carId||activeCar)===c.id?'selected':''}>${html(c.brand+' '+c.model)}</option>`).join('');
const content=`<label>Auto<select name="carId">${cs}</select></label><label>Datum<input id="rec-date" type="date" name="date" required value="${html(old.date||today())}"></label><label>Název záznamu<input id="rec-title" name="title" required value="${html(old.title||(isOdo?'Stav tachometru':''))}" placeholder="Výměna oleje, brzdy…"></label><label>Kilometry<input id="rec-km" name="km" type="number" min="0" ${isOdo?'required':''} inputmode="numeric" value="${html(old.km||'')}"></label>${isOdo?'':`<label>Cena v Kč<input id="rec-price" name="price" type="number" step="0.01" min="0" value="${html(old.price||'')}"></label>`}<label>Poznámky<textarea name="note" rows="3">${html(old.note||'')}</textarea></label><label>${isOdo?'Fotografie tachometru (galerie)':'Vybrat z telefonu (galerie, PDF, Excel, CSV)'}<input name="photo" id="photo-upload" type="file" accept="${isOdo?'image/*':'image/*,.pdf,.xlsx,.xls,.xlsm,.csv,application/pdf'}"></label><button type="button" id="run-ocr" class="secondary read-btn">🔎 ${isOdo?'Přečíst kilometry':'Přečíst fakturu'}</button><div id="ocr-progress" aria-live="polite">Čtení spustíš po nahrání. Vyžaduje internet při načtení OCR.</div>${isOdo?`<div id="odo-select-tools" hidden><p><b>📍 Přesnější načtení kilometrů</b></p><p class="hint">Když se kilometry nepřečtou automaticky, prstem označ na fotografii jen celkové číslo kilometrů (bez data, času a „trip“).</p><canvas id="odo-select-canvas" style="width:100%;height:auto;border:1px solid #9caec4;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="odo-read-selected" class="secondary" disabled>🔎 Přečíst označené km</button><button type="button" id="odo-view-toggle" class="ghost">Zobrazit celý snímek</button></div></div>`:''}<label>Rozpoznaný text – můžeš vymazat či opravit jednotlivé údaje<textarea id="ocr-text" name="ocrText" rows="6" placeholder="Text rozpoznaný z faktury">${html(old.ocrText||'')}</textarea></label><div id="redact-tools" hidden><p><b>Začernění údajů na fotografii</b></p><p class="hint">Prstem táhni přes část faktury, kterou chceš skrýt. Uloží se pouze upravená fotografie. Původní snímek není součástí zálohy.</p><canvas id="redact-canvas" style="width:100%;height:auto;border:1px solid #b9c6d7;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="redact-undo" class="secondary">↶ Vrátit poslední</button><button type="button" id="redact-reset" class="ghost">Zrušit začernění</button></div></div><div class="actions"><button type="button" class="ghost" id="remove-attachment">🗑 Odebrat přílohu</button></div><div id="attached" class="note">${old.fileData?`Uložená příloha: <a href="${old.fileData}" download="${html(old.fileName||'priloha')}">Otevřít / stáhnout</a>`:'Bez přílohy'}</div><p class="warning">OCR může údaje přečíst nesprávně, zejména ceny a kilometry. Před uložením je potvrď. Začernění přímo v příloze platí jen pro fotografie. Z PDF/Excelu lze odstranit údaje z přepisu, ale původní dokument zůstane beze změny. Citlivé soubory před přiložením uprav mimo aplikaci.</p>`;
let tools;
modal(id?'Upravit záznam':(isOdo?'Nový stav tachometru':'Nový servisní záznam'),content,async f=>{try{const attachment=await tools.attachment();const r={id:id||uid(),type:isOdo?'odo':'service',carId:f.get('carId'),date:f.get('date'),title:f.get('title').trim(),km:f.get('km'),price:isOdo?0:f.get('price'),note:f.get('note').trim(),ocrText:f.get('ocrText').trim(),...attachment};const proposed=id?db.records.map(x=>x.id===id?r:x):[...db.records,r];const before=db.records;db.records=proposed;if(save()){close();notice('Záznam uložen')}else db.records=before}catch(e){alert(e.message)}},id?()=>{db.records=db.records.filter(r=>r.id!==id);save()}:null);
tools=setupPhotoTools(old,isOdo);
}
$('add-invoice').onclick=()=>openRecord(null,'service');$('add-service').onclick=()=>openRecord(null,'service');$('add-odo').onclick=()=>openRecord(null,'odo');$('history-add').onclick=()=>openRecord(null,'service');
$('export').onclick=()=>{const blob=new Blob([JSON.stringify({format:'mojeauto-v1',...db},null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='moje-auto-zaloha-'+today()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),3000)};
$('import-button').onclick=()=>$('import-file').click();$('import-file').onchange=async e=>{try{const x=JSON.parse(await e.target.files[0].text());if(!Array.isArray(x.cars)||!Array.isArray(x.records))throw Error('Nesprávný formát');if(confirm('Obnovit zálohu? Aktuální záznamy budou nahrazeny.')){db={cars:x.cars,records:x.records};if(save()){activeCar=null;render();notice('Záloha obnovena')}}}catch(err){alert('Neplatná záloha: '+err.message)}e.target.value=''};
// Funkce cloudu v této offline mobilní verzi není aktivní; nedovolujeme uložit klíče bez připojení.
$('settings').querySelector('h2').textContent='Nastavení a záloha';$('settings').querySelector('.panel').style.display='none';
render();if(activeCar)attachRecords();
if('serviceWorker'in navigator && location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
