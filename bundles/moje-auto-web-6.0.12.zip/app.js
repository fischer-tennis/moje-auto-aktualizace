// V6.4 – výběr cizích položek faktury jedním klepnutím.
'use strict';
const $=id=>document.getElementById(id), key='mojeauto_v1';
let db={cars:[],records:[]}, editing=null, activeCar=null;
try{const x=JSON.parse(localStorage.getItem(key)||'null');if(x&&Array.isArray(x.cars)&&Array.isArray(x.records))db=x}catch{}
const save=()=>{try{localStorage.setItem(key,JSON.stringify(db));return true}catch(e){alert('Nepodařilo se uložit. Úložiště telefonu může být plné. Proveď zálohu a zmenši fotografie.');return false}};
const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random());
const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>{const val=Number(n||0);return val.toLocaleString('cs-CZ',{style:'currency',currency:'CZK',minimumFractionDigits:Math.abs(val-Math.round(val))>.0001?2:0,maximumFractionDigits:2})};
const date=d=>d?new Date(d+'T12:00:00').toLocaleDateString('cs-CZ'):'—';

// Původní faktura se nikdy nemění. Odečítáme jen položky, které nebyly pro toto auto.
function amountInCents(raw){
 const v=String(raw??'').trim().replace(/[\u00a0\u202f\s]/g,'').replace(',','.');
 if(v==='')return null;
 if(!/^\d+(?:\.\d{1,2})?$/.test(v))throw Error('Částku zadej jako kladné číslo s nejvýše dvěma desetinnými místy.');
 const n=Number(v);if(!Number.isFinite(n)||n>100000000)throw Error('Částka je příliš vysoká.');
 return Math.round(n*100);
}
function computeInvoiceShare(totalRaw, excluded=[]){
 const gross=amountInCents(totalRaw);
 let other=0;
 for(const item of excluded){
  const title=String(item.title??'').trim(),raw=item.amount;
  if(!title && String(raw??'').trim()==='')continue;
  if(!title)throw Error('U odečítané položky doplň název.');
  const cents=amountInCents(raw);
  if(cents===null||cents<=0)throw Error('U položky „'+title+'“ uveď částku včetně DPH větší než nula.');
  other+=cents;
 }
 if(gross===null){if(other)throw Error('Nejdříve vyplň celkovou cenu faktur včetně DPH.');return {gross:'',excluded:other/100,own:''}}
 if(other>gross)throw Error('Odečítané položky nemohou být dražší než celá faktura.');
 return {gross:gross/100,excluded:other/100,own:(gross-other)/100};
}

function notice(s){$('toast').textContent=s;setTimeout(()=>$('toast').textContent='',3300)}
function showTab(t){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('active',e.id===t));document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('active',e.dataset.view===t));render()}
document.querySelectorAll('.tab').forEach(e=>e.addEventListener('click',()=>showTab(e.dataset.view)));
const carName=id=>{const c=db.cars.find(x=>x.id===id);return c?`${c.brand} ${c.model}`:'Neznámé auto'};
function render(){const cars=$('car-list');cars.innerHTML=db.cars.length?db.cars.map(c=>`<button class="car ${c.id===activeCar?'selected':''}" data-car="${html(c.id)}"><div><b>🚘 ${html(c.brand)} ${html(c.model)}</b><small>${html(c.plate||'Bez SPZ')} · ${html(c.year||'Rok neuveden')}</small></div><span>✎</span></button>`).join(''):'<div class="panel">Zatím nemáš uložené žádné auto. Začni tlačítkem „Přidat auto“.</div>';
cars.querySelectorAll('[data-car]').forEach(b=>b.onclick=()=>{activeCar=b.dataset.car;render();});
if(!db.cars.some(c=>c.id===activeCar))activeCar=db.cars[0]?.id||null;
$('overview-details').hidden=!activeCar;
if(activeCar){const rs=db.records.filter(r=>r.carId===activeCar);const odo=rs.filter(r=>Number(r.km)>0).sort((a,b)=>Number(b.km)-Number(a.km))[0];$('stats').innerHTML=`<div class="stat"><small>Vybrané auto</small><strong>${html(carName(activeCar))}</strong><button class="secondary" id="edit-car">Upravit auto</button></div><div class="stat"><small>Poslední stav tachometru</small><strong>${odo?Number(odo.km).toLocaleString('cs-CZ')+' km':'—'}</strong></div><div class="stat"><small>Celkové servisní náklady</small><strong>${money(rs.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</strong></div>`;$('edit-car').onclick=()=>openCar(activeCar);$('recent').innerHTML=listRecords(rs.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5));}
$('history-car').innerHTML='<option value="all">Všechna auta</option>'+db.cars.map(c=>`<option value="${html(c.id)}">${html(c.brand+' '+c.model)}</option>`).join('');const selected=$('history-car').dataset.selected||'all';$('history-car').value=[...$('history-car').options].some(o=>o.value===selected)?selected:'all';renderHistory();renderCosts();attachRecords();renderCarBiographyButton();}
function listRecords(rows){if(!rows.length)return'<p class="note">Zatím žádné záznamy.</p>';return rows.map(r=>`<button class="record" data-rec="${html(r.id)}"><div><b>${r.type==='odo'?'📸':'🔧'} ${html(r.title)}</b><small>${html(carName(r.carId))} · ${date(r.date)} ${r.km?'· '+Number(r.km).toLocaleString('cs-CZ')+' km':''}</small></div><b>${r.type==='service'?money(r.price):'›'}</b></button>`).join('')}
function attachRecords(){document.querySelectorAll('[data-rec]').forEach(b=>b.onclick=()=>openRecord(b.dataset.rec))}
function renderHistory(){let rows=db.records;let car=$('history-car').value;if(car!=='all')rows=rows.filter(r=>r.carId===car);let q=$('history-search').value.trim().toLowerCase();if(q)rows=rows.filter(r=>(r.title+' '+r.note+' '+carName(r.carId)).toLowerCase().includes(q));$('history-list').innerHTML=listRecords(rows.slice().sort((a,b)=>b.date.localeCompare(a.date)));attachRecords()}
function renderCosts(){let sum=db.records.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0);$('costs-body').innerHTML=`<div class="stat"><small>Celkové servisní náklady</small><strong>${money(sum)}</strong></div>`+db.cars.map(c=>`<div class="record"><b>${html(c.brand+' '+c.model)}</b><b>${money(db.records.filter(r=>r.carId===c.id&&r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</b></div>`).join('')}
$('history-car').onchange=()=>{$('history-car').dataset.selected=$('history-car').value;renderHistory()};$('history-search').oninput=renderHistory;
function modal(title,body,onSubmit,onDelete){$('editor-title').textContent=title;$('editor-fields').innerHTML=body;$('editor').showModal();$('editor-form').onsubmit=e=>{e.preventDefault();onSubmit(new FormData(e.currentTarget))};$('delete-item').hidden=!onDelete;$('delete-item').onclick=async()=>{if(confirm('Opravdu smazat?')){try{const done=await onDelete();if(done!==false){$('editor').close();render()}}catch(err){alert('Smazání se nezdařilo: '+err.message)}}}}
function close(){ $('editor').close();render() }$('close-dialog').onclick=close;$('cancel-dialog').onclick=close;
function openCar(id){const c=db.cars.find(x=>x.id===id)||{};modal(id?'Upravit auto':'Přidat auto',`<label>Značka<input name="brand" required value="${html(c.brand||'')}"></label><label>Model<input name="model" required value="${html(c.model||'')}"></label><label>SPZ<input name="plate" value="${html(c.plate||'')}"></label><label>Rok výroby<input name="year" inputmode="numeric" value="${html(c.year||'')}"></label><label>VIN (volitelné)<input name="vin" value="${html(c.vin||'')}"></label>`,f=>{const x={id:id||uid(),brand:f.get('brand').trim(),model:f.get('model').trim(),plate:f.get('plate').trim(),year:f.get('year').trim(),vin:f.get('vin').trim()};if(id)db.cars=db.cars.map(z=>z.id===id?x:z);else db.cars.push(x);activeCar=x.id;if(save())close()},id?async()=>{const oldCars=db.cars,oldRecords=db.records;db.cars=db.cars.filter(c=>c.id!==id);db.records=db.records.filter(r=>r.carId!==id);if(!save()){db.cars=oldCars;db.records=oldRecords;return false}try{await removeFiles(oldRecords.filter(r=>r.carId===id).flatMap(r=>(r.attachments||[]).map(a=>a.id)))}catch(e){console.warn(e)}return true}:null)}
$('add-car').onclick=()=>openCar();
const today=()=>new Date().toLocaleDateString('sv-SE');
// OCR běží přímo v prohlížeči, bez odesílání fotografie na server.
const injectScript=(url)=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=url;s.onload=ok;s.onerror=()=>no(Error('Nepodařilo se načíst OCR knihovnu. Zkontroluj internet.'));document.head.appendChild(s)});
let ocrReady=false,pdfReady=false;
async function ocrImage(file,onProgress){if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}const worker=await Tesseract.createWorker('ces+eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení textu: '+Math.round((e.progress||0)*100)+' %')}});try{const r=await worker.recognize(file);return r.data.text}finally{await worker.terminate()}}
// Tachometr V6.1: světlé číslice na tmavém displeji převedeme na černé číslice
// na bílém podkladu. Když automatika selže, lze vybrat prstem jen oblast kilometrů.
function odometerCandidates(text,job,confidence=0){
 const rows=String(text||'').replace(/[|]/g,'1').split(/\r?\n/).map(s=>s.trim()).filter(Boolean),found=[];
 for(let i=0;i<rows.length;i++){
  let line=rows[i];
  // I / l uvnitř čísla bývá na displeji OCR často zaměněné za jedničku.
  line=line.replace(/(?<=[\d\s])[Il](?=\d)/g,'1').replace(/(?<=\d)[Il](?=\s|$)/g,'1').replace(/(?<=\d)[OoQ](?=\d)/g,'0');
  const hasKm=/\b(?:km|kms|odo|odometer)\b/i.test(line)||/\bkm\b/i.test(rows[i-1]||'')||/\bkm\b/i.test(rows[i+1]||'');
  const hasTrip=/\b(?:trip|denn[ií]|daily)\b/i.test(line);
  // Datum, hodiny a denní počítadlo nesmějí soutěžit s celkovými kilometry.
  const cleaned=line
   .replace(/\b[0-3]?\d[.\/-][01]?\d[.\/-](?:20)?\d{2,4}\b/g,' ')
   .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g,' ')
   .replace(/\b(?:trip|denn[ií]|daily)\s*[:=]?\s*\d+(?:[.,]\d+)?\b/gi,' ');
  for(const match of cleaned.matchAll(/(?<!\d)\d(?:[ \u00a0\u202f.]?\d){2,8}(?!\d)/g)){
   const digits=match[0].replace(/\D/g,'');
   if(digits.length<3||digits.length>7)continue;
   if(!hasKm&&!job.manual&&Number(digits)<10000)continue;
   if(hasTrip&&!hasKm&&!job.manual)continue;
   const n=Number(digits);
   if(n<1||n>9999999)continue;
   const weight=job.weight+(hasKm?7:0)+(digits.length>=5?2:0)+(Math.min(4,Math.max(0,confidence)/25));
   found.push({n,weight,conf:confidence,hasKm,manual:!!job.manual,focus:!!job.focus});
  }
 }
 return found;
}
function odometerImage(img,box,mode='bright'){
 const width=img.width,height=img.height;
 let [x,y,w,h]=box;
 x=Math.max(0,Math.min(.99,x));y=Math.max(0,Math.min(.99,y));
 w=Math.max(.015,Math.min(1-x,w));h=Math.max(.015,Math.min(1-y,h));
 const sx=Math.floor(x*width),sy=Math.floor(y*height),sw=Math.max(1,Math.floor(w*width)),sh=Math.max(1,Math.floor(h*height));
 const factor=Math.min(7,2200/sw,1600/sh);
 const canvas=document.createElement('canvas');
 canvas.width=Math.max(1,Math.round(sw*factor));canvas.height=Math.max(1,Math.round(sh*factor));
 const ctx=canvas.getContext('2d',{willReadFrequently:true});
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
 ctx.drawImage(img,sx,sy,sw,sh,0,0,canvas.width,canvas.height);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),a=pixels.data;
 const hist=new Uint32Array(256);
 for(let i=0;i<a.length;i+=4){const lum=Math.round(a[i]*.299+a[i+1]*.587+a[i+2]*.114);hist[lum]++}
 function percentile(p){let target=canvas.width*canvas.height*p,acc=0;for(let i=0;i<256;i++){acc+=hist[i];if(acc>=target)return i}return 255}
 const middle=percentile(.5),top=percentile(.9),bottom=percentile(.12);
 const isLightOnDark=middle<149;
 let threshold=isLightOnDark?Math.min(215,Math.max(91,top-5)):Math.min(205,Math.max(55,bottom+18));
 if(mode==='bright-soft')threshold+=isLightOnDark?-15:15;
 for(let i=0;i<a.length;i+=4){const lum=a[i]*.299+a[i+1]*.587+a[i+2]*.114;
  let v;if(mode==='bright'||mode==='bright-soft')v=isLightOnDark?(lum>=threshold?0:255):(lum<threshold?0:255);
  else {const normalized=Math.max(0,Math.min(255,(lum-bottom)*255/Math.max(20,top-bottom)));v=isLightOnDark?255-normalized:normalized}
  a[i]=a[i+1]=a[i+2]=v;a[i+3]=255;
 }
 ctx.putImageData(pixels,0,0);return canvas;
}
async function readOdometer(file,onProgress,selectedBox=null){
 if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}
 const img=await createImageBitmap(file),readings=[],found=[];
 const manual=!!selectedBox;
 const jobs=manual?[
  {name:'označená oblast – číslice',box:selectedBox,mode:'bright',psm:6,onlyDigits:true,weight:9,manual:true,focus:true},
  {name:'označená oblast – jemnější práh',box:selectedBox,mode:'bright-soft',psm:7,onlyDigits:true,weight:8,manual:true,focus:true}
 ]:[
  {name:'celkové kilometry – detail',box:[.262,.545,.245,.125],mode:'bright',psm:6,onlyDigits:true,weight:7,focus:true},
  {name:'celkové kilometry – jiný kontrast',box:[.262,.545,.245,.125],mode:'bright-soft',psm:7,onlyDigits:true,weight:7,focus:true},
  {name:'dolní displej s označením km',box:[.12,.42,.77,.39],mode:'bright',psm:11,onlyDigits:false,weight:3},
  {name:'celý středový displej',box:[.15,.17,.7,.68],mode:'contrast',psm:11,onlyDigits:false,weight:1}
 ];
 let worker;
 try{
  worker=await Tesseract.createWorker('eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení tachometru: '+Math.round((e.progress||0)*100)+' %')}});
  for(const job of jobs){
   onProgress('Hledám kilometry: '+job.name+'…');
   await worker.setParameters({tessedit_pageseg_mode:job.psm,tessedit_char_whitelist:job.onlyDigits?'0123456789 ':''});
   const canvas=odometerImage(img,job.box,job.mode);
   const result=await worker.recognize(canvas),txt=String(result.data.text||'').trim();
   const conf=Number(result.data.confidence)||0;
   readings.push(job.name+': '+(txt||'(nepřečteno)'));
   found.push(...odometerCandidates(txt,job,conf));
  }
 }finally{if(worker)await worker.terminate();img.close?.()}
 const grouped=new Map();
 for(const c of found){let g=grouped.get(c.n);if(!g){g={n:c.n,score:0,hits:0,conf:0,hasKm:false,manual:false,focus:false};grouped.set(c.n,g)}
  g.score+=c.weight;g.hits++;g.conf=Math.max(g.conf,c.conf);g.hasKm ||=c.hasKm;g.manual ||=c.manual;g.focus ||=c.focus;
 }
 const ranking=[...grouped.values()].sort((a,b)=>b.score-a.score||b.hits-a.hits);
 const best=ranking[0],second=ranking[1];
 const consistent=!!best&&(!second||best.score>=second.score+5);
 const reliable=!!best&&consistent&&(
   best.hits>=2 || best.hasKm&&best.conf>=50 || best.focus&&best.conf>=83&&String(best.n).length>=5
 );
 return {km:reliable?String(best.n):'',suggestion:best?String(best.n):'',reliable,
  text:readings.join('\n\n'),alternatives:ranking.slice(1,3).map(r=>r.n)};
}
async function ensurePdf(){if(!pdfReady){await injectScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';pdfReady=true}}
async function readPdf(file,onProgress){await ensurePdf();const d=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise;let text='';for(let i=1;i<=Math.min(d.numPages,8);i++){onProgress(`Čtu PDF: stránka ${i} z ${Math.min(d.numPages,8)}`);const pg=await d.getPage(i),tc=await pg.getTextContent();let pageText=tc.items.map(x=>({text:x.str||'',y:Math.round((x.transform?.[5]||0)/3)*3,x:x.transform?.[4]||0})).sort((a,b)=>b.y-a.y||a.x-b.x).reduce((acc,it)=>{if(!acc.length||acc[acc.length-1].y!==it.y)acc.push({y:it.y,parts:[it.text]});else acc[acc.length-1].parts.push(it.text);return acc},[]).map(row=>row.parts.join(' ')).join('\n');if(pageText.trim().length<25){onProgress(`Rozpoznávám sken PDF: stránka ${i}`);const viewport=pg.getViewport({scale:2});const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;await pg.render({canvasContext:canvas.getContext('2d'),viewport}).promise;pageText=await ocrImage(canvas,onProgress)}text+=pageText+'\n'}return text}
let sheetReady=false;
async function readSpreadsheet(file,onProgress){if(!sheetReady){await injectScript('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js');sheetReady=true}onProgress('Čtu tabulky Excelu…');const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true,cellText:true});return wb.SheetNames.slice(0,12).map(name=>{const sheet=wb.Sheets[name];const rows=XLSX.utils.sheet_to_json(sheet,{header:1,defval:'',raw:false}).filter(row=>row.some(c=>String(c).trim()));return 'List '+name+'\n'+rows.map(row=>row.map(c=>String(c).replace(/[\r\n|]+/g,' ').trim()).join(' | ')).join('\n')}).join('\n\n').slice(0,100000)}
async function readDocument(file,onProgress){const n=file.name.toLowerCase();if(n.endsWith('.pdf'))return readPdf(file,onProgress);if(/\.(xlsx|xls|xlsm|csv)$/.test(n))return readSpreadsheet(file,onProgress);if(file.type.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/.test(n))return ocrImage(file,onProgress);throw Error('Nepodporovaný formát. Nahraj PDF, Excel, CSV nebo obrázek.')}
// Částky z faktur: vždy preferujeme „k úhradě / s DPH“, nikoliv „bez DPH“.
function parseInvoiceAmount(value){
 const t=String(value||'').replace(/[\u00a0\u202f\s]/g,'').replace(/[^\d,.-]/g,'');
 if(!t||!/[0-9]/.test(t))return null;
 const comma=t.lastIndexOf(','),dot=t.lastIndexOf('.');let normalized=t;
 if(comma>=0&&dot>=0){const sep=comma>dot?',':'.';normalized=t.replace(sep===','?/\./g:/,/g,'').replace(sep, '.');}
 else if(comma>=0){normalized=/,\d{1,2}$/.test(t)?t.replace(/\./g,'').replace(',','.'):t.replace(/,/g,'');}
 else if(dot>=0){normalized=/\.\d{1,2}$/.test(t)?t.replace(/,/g,''):t.replace(/\./g,'');}
 const n=Number(normalized);return Number.isFinite(n)&&n>=0&&n<=100000000?Math.round(n*100)/100:null;
}
function amountsOnLine(line){
 // Odstranit datové řetězce, čísla faktur, sazby „21 %“ a časové údaje.
 const cleaned=String(line).replace(/\b[0-3]?\d[.\/-][01]?\d[.\/-](?:20)?\d{2,4}\b/g,' ')
  .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g,' ').replace(/\b\d{1,2}(?:[,.]\d+)?\s*%/g,' ');
 const parts=[...cleaned.matchAll(/(?<![\dA-Za-z])(?:\d{1,3}(?:[ \u00a0\u202f.]\d{3})+|\d{1,9})(?:[,.]\d{1,2})?(?![\dA-Za-z])/g)].map(m=>parseInvoiceAmount(m[0])).filter(n=>n!==null);
 return parts;
}
function extractFields(text){
 const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const d=String(text).match(/\b([0-3]?\d)[.\/\-]\s*([01]?\d)[.\/\-]\s*(20\d\d)\b/);
 const isoDate=d?`${d[3]}-${d[2].padStart(2,'0')}-${d[1].padStart(2,'0')}`:'';
 let gross=null,net=null,vat=null,grossScore=-1,netScore=-1,vatScore=-1;const taxRows=[];
 for(let i=0;i<lines.length;i++){
  const line=lines[i],normalized=line.toLocaleLowerCase('cs-CZ');
  const isWithout=/bez\s*dph|bez\s*dan[eě]|without\s*(?:vat|tax)|excl\.?\s*vat|ex\s*vat|z[aá]klad\s*(?:dan[eě]|dph)|da[nň]ov[yý]\s*z[aá]klad|subtotal|mezisou[cč]et/.test(normalized);
  const isIncluding=/v[cč]\.?\s*dph|v[cč]etn[eě]\s*dph|s\s*dph|po\s*zdan[eě]n[ií]|incl\.?\s*vat|including\s*vat|with\s*vat/.test(normalized);
  const isPayable=/k\s*[uú]hrad[eě]|celkem\s*k\s*zaplacen[ií]|[uú]hrad[aě]|amount\s*due|to\s*pay|k\s*placen[ií]|grand\s*total/.test(normalized);
  const isTotal=/celkem|celkov[aá]\s*(?:cena|[cč][aá]stka)|total|sou[cč]et|fakturovan[aá]\s*[cč][aá]stka/.test(normalized);
  const isVat=/\bdph\b|\bvat\b|da[nň]\s*(?:21|12|15|10|0)?\s*%?|v[yý][sš]e\s*dan[eě]/.test(normalized);
  const values=amountsOnLine(line);
  if(!values.length)continue;
  // Na řádku s číselnou sazbou a částkami bývá konečná částka poslední.
  const last=values[values.length-1];
  const netRank=isWithout?(isTotal?90:80):-1;
  if(netRank>netScore){net=last;netScore=netRank;}
  let grossRank=-1;
  if(isPayable)grossRank=120;
  else if(isIncluding&&isTotal)grossRank=110;
  else if(isIncluding)grossRank=100;
  else if(isTotal&&!isWithout&&!isVat)grossRank=70;
  else if(isTotal&&!isWithout&&isVat&&isIncluding)grossRank=105;
  if(grossRank>grossScore){gross=last;grossScore=grossRank;}
  if(isVat&&!isIncluding&&!isWithout&&!isPayable){
   const vRank=/dph\s*(?:celkem|[cč][aá]stka|[kč][cč])|v[yý][sš]e\s*dan[eě]|vat\s*(?:amount|total)/.test(normalized)?90:60;
   // V typickém řádku sazba / základ / DPH je DPH poslední položka.
   const taxCandidate=last;if(vRank<90)taxRows.push(last);
   if(vRank>vatScore){vat=taxCandidate;vatScore=vRank;}
  }
 }
 // Pokud jsou na faktuře dvě různé sazby, sečteme jednotlivé daňové řádky;
 // řádek explicitně nazvaný „DPH celkem“ však má stále přednost.
 if(vatScore<90&&taxRows.length>1)vat=Math.round(taxRows.reduce((sum,n)=>sum+n,0)*100)/100;
 // Např. OCR řádek „Celkem bez DPH 2000“ se nikdy nesmí vydávat za platbu.
 // Pokud je na faktuře explicitně základ a DPH, lze jejich součet dopočítat.
 let calculated=false;
 if(gross===null&&net!==null&&vat!==null){gross=Math.round((net+vat)*100)/100;calculated=true;}
 if(gross!==null&&net!==null&&vat===null&&gross>=net){vat=Math.round((gross-net)*100)/100;}
 if(gross!==null&&vat!==null&&net===null&&gross>=vat){net=Math.round((gross-vat)*100)/100;}
 const kmMatch=String(text).match(/(?:tachometr|stav\s*km|najeto|kilometr(?:[uůy])?|odo(?:meter)?)\D{0,22}(\d[\d\s]{1,8})\s*(?:km)?/i);
 return {date:isoDate,price:gross??'',priceWithoutVat:net??'',vatAmount:vat??'',calculated,
  needsReview:gross===null,title:lines.find(l=>/v[yý]m[eě]na|olej|filtr|brzdy|servis|oprava|rozvody/i.test(l))?.slice(0,100)||'',
  km:kmMatch?kmMatch[1].replace(/\s/g,''):'',note:String(text).trim()};
}
// V6.4: položky dokladu přečtené pomocí OCR/PDF/Excelu – výběr klepnutím.
// Toto je pomocný odhad řádkových cen, nikoli účetní ověření faktury.
function normalizeInvoiceItemName(raw){
 return String(raw||'').replace(/\s+/g,' ').replace(/^\s*(?:(?:\d+[.)-]|[#.])\s*)+/, '').trim().slice(0,140);
}
function invoiceItemKey(source,index,label){
 return `${String(source).toLocaleLowerCase('cs-CZ')}|${index}|${String(label).toLocaleLowerCase('cs-CZ').replace(/\s+/g,' ').slice(0,65)}`;
}
function invoiceTaxRate(line){
 const m=String(line).match(/(?:^|\s|[,;|])(?:DPH\s*)?(21|12|15|10|0)(?:[.,]0{1,2})?\s*%/i);
 return m?Number(m[1]):null;
}
function findInvoiceRows(ocrText,source='Faktura'){
 const lines=String(ocrText||'').split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
 const header=lines.filter(l=>/(?:položk|popis|název|nazev|množstv|mnozstv|jednotkov|mj\b)/i.test(l)&&/(?:cena|dph|price|vat)/i.test(l)).join(' ');
 const globalNet=/\bbez\s*dph\b|price\s*(?:without|excl)|cena\s*bez\s*dan[eě]/i.test(header)&&!/v[cč]etn[eě]\s*dph|\bs\s*dph|\bv[cč]\.?\s*dph|\bwith\s*vat/i.test(header);
 const found=[];const ignore=/(?:^|\s)(?:celkem|sou[cč]et|mezisou[cč]et|k\s*[uú]hrad[eě]|k\s*zaplacen[ií]|z[aá]klad\s*(?:dan[eě]|dph)|dph\s*celkem|datum|objedn[aá]vk|variabiln[ií]\s*symbol|iban|bankovn[ií]|faktur[aá]\s*(?:[cč]|[cč][ií]slo)|platebn[ií]|zaplaceno|[cč][aá]stka\s*dph|celkov[aá]\s*cena|grand\s*total|subtotal|amount\s*due|tax\s*total|payment)/i;
 for(let index=0;index<lines.length;index++){
  let line=lines[index];if(ignore.test(line))continue;
  // U skenů se může cena objevit až na následujícím řádku.
  if(!amountsOnLine(line).length && index+1<lines.length && /^\s*[\d\s.,%|;]+(?:\s*(?:kč|czk|eur))?\s*$/i.test(lines[index+1])){
   line+=' | '+lines[++index];
  }
  let values=amountsOnLine(line);
  if(!values.length||values.length>14||!/[\p{L}]/u.test(line))continue;
  const isTable=/[|;\t]/.test(line);
  const hasMoney=/\d[,.]\d{2}(?!\d)|\d[ \u00a0\u202f]\d{3}(?!\d)|(?:k[cč]|czk|eur|€)/i.test(line);
  if(!hasMoney && !(isTable&&values.length>=2))continue;
  let label='';
  if(isTable){label=line.split(/[|;\t]/)[0].trim()}
  else{
   // Částku oddělíme od názvu; čísla v označeních jako 5W30 necháme v názvu.
   const amountStarts=[...line.matchAll(/(?<![\p{L}\d])\d{1,3}(?:[ \u00a0\u202f.]\d{3})+(?:[,.]\d{1,2})?|(?<![\p{L}\d])\d{1,8}[,.]\d{2}(?!\d)/gu)];
   const first=amountStarts.find(m=>m.index>1);
   label=first?line.slice(0,first.index).trim():line.replace(/\s+\d+(?:\s*(?:kč|czk|eur))?\s*$/i,'').trim();
   label=label.replace(/\s+\d+(?:[,.]\d+)?\s*(?:ks|kus|kusy|l|ml|h|hod|bal|m|mj)\s*$/i,'').trim();
  }
  label=normalizeInvoiceItemName(label.replace(/(?:^|\s)\d+[.)]\s*/, ' '));
  if(label.length<3||ignore.test(label)||/^(?:DPH|VAT|ks|kus|cena|sleva|položka|sazba|price|amount|množstv[ií]|doprava\s*celkem)$/i.test(label))continue;
  // OCR běžně vytváří položky typu "21 %" – nejsou to ceny.
  const rate=invoiceTaxRate(line);
  if(/\b\d{1,2}\s*%\s*$/.test(line)&&values.length===1)continue;
  let gross=values[values.length-1];let estimate=false;
  const explicitNet=/\bbez\s*dph\b|without\s*vat|excl\.?\s*vat/i.test(line);
  const explicitGross=/v[cč]etn[eě]\s*dph|\bs\s*dph|incl\.?\s*vat/i.test(line);
  // Poslední dva sloupce mohou být "bez DPH" a "s DPH".
  let lastAlreadyGross=false;
  if(rate!==null&&values.length>=2){
   const prior=values[values.length-2];
   lastAlreadyGross=Math.abs(gross-prior*(1+rate/100))<=.07;
  }
  if((globalNet||explicitNet)&&!explicitGross&&!lastAlreadyGross&&rate!==null){
   gross=Math.round(gross*(100+rate))/100;estimate=true;
  }
  if(gross<=0||gross>10000000)continue;
  // Odfiltrovat záhlaví se samotným údajem DPH, které OCR připomíná položku.
  if(/^(?:dph|vat|sazba|z[aá]klad|z[aá]loha|da[nň]|cena\s*(?:za|bez|s))/i.test(label))continue;
  found.push({key:invoiceItemKey(source,index,label),source:String(source),title:label,amount:gross,excluded:false,estimate,raw:line.slice(0,300)});
  if(found.length>=180)break;
 }
 return found;
}
function invoiceRowsFromSavedText(text){
 const result=[];const str=String(text||'');
 const groups=str.split(/^=== (.+?) ===\s*$/m);
 if(groups.length<3)return findInvoiceRows(str,'Uložený přepis');
 for(let i=1;i<groups.length;i+=2){
  const name=groups[i],body=(groups[i+1]||'').replace(/--- Výsledek:.*$/ms,'');
  result.push(...findInvoiceRows(body,name));
 }
 return result;
}
let workingInvoiceRows=[];
function selectedInvoiceRows(){return workingInvoiceRows.filter(x=>x.excluded).map(x=>({title:x.title,amount:x.amount,sourceKey:x.key,source:x.source}))}
function mergeScannedInvoiceRows(scanned){
 const oldByKey=new Map(workingInvoiceRows.map(x=>[x.key,x]));
 const oldByContent=new Map(workingInvoiceRows.map(x=>[`${x.source}|${x.title}|${x.amount}`,x]));
 const next=[];const seen=new Set();
 for(const item of scanned){
  if(seen.has(item.key))continue;seen.add(item.key);
  const previous=oldByKey.get(item.key)||oldByContent.get(`${item.source}|${item.title}|${item.amount}`);
  next.push({...item,excluded:!!previous?.excluded});
 }
 workingInvoiceRows=next;
 renderInvoiceRowPicker();
}
function renderInvoiceRowPicker(){
 const list=$('invoice-rows-list'),status=$('invoice-rows-status');if(!list||!status)return;
 list.replaceChildren();
 if(!workingInvoiceRows.length){
  status.textContent='Zatím nebyly rozpoznány položky. Nahraj doklad a spusť čtení faktur.';
  return;
 }
 const count=workingInvoiceRows.filter(x=>x.excluded).length;
 status.textContent=`Rozpoznáno ${workingInvoiceRows.length} položek. ${count} nezapočítáno. Částky z OCR vždy zkontroluj s fakturou.`;
 let lastSource='';
 for(const item of workingInvoiceRows){
  if(lastSource!==item.source){
   const sub=document.createElement('h4');sub.className='invoice-item-source';sub.textContent='📄 '+item.source;list.appendChild(sub);lastSource=item.source;
  }
  const wrap=document.createElement('label');wrap.className='invoice-choice'+(item.excluded?' excluded':'');
  const check=document.createElement('input');check.type='checkbox';check.checked=!!item.excluded;check.setAttribute('aria-label','Nezapočítat '+item.title);
  const body=document.createElement('span');body.className='invoice-choice-name';body.textContent=item.title;
  const amount=document.createElement('span');amount.className='invoice-choice-amount';amount.textContent=money(item.amount);
  const detail=document.createElement('small');detail.textContent=item.excluded?'❌ Nezapočítáno do nákladů':(item.estimate?'DPH dopočítána – ověř':'Klepnutím nezapočítáš položku');
  const text=document.createElement('span');text.className='invoice-choice-main';text.append(body,detail);
  check.onchange=()=>{item.excluded=check.checked;wrap.classList.toggle('excluded',check.checked);detail.textContent=check.checked?'❌ Nezapočítáno do nákladů':(item.estimate?'DPH dopočítána – ověř':'Klepnutím nezapočítáš položku');status.textContent=`Rozpoznáno ${workingInvoiceRows.length} položek. ${workingInvoiceRows.filter(x=>x.excluded).length} nezapočítáno. Částky z OCR vždy zkontroluj s fakturou.`;updatePriceSummary()};
  wrap.append(check,text,amount);list.appendChild(wrap);
 }
}
// Přílohy patří do IndexedDB (Blob), nikoli do malého limitu localStorage.
// Starší záznamy s fileData zůstávají kompatibilní.
const FILE_DB_NAME='mojeauto_prilohy_v2';
let fileDBPromise;
function openFileDB(){
 if(!fileDBPromise)fileDBPromise=new Promise((resolve,reject)=>{
  if(!window.indexedDB){reject(Error('Tento telefon nepodporuje lokální databázi příloh.'));return}
  const req=indexedDB.open(FILE_DB_NAME,1);
  req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('files'))req.result.createObjectStore('files',{keyPath:'id'})};
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||Error('Databázi příloh nelze otevřít'));
 });
 return fileDBPromise;
}
async function writeFiles(entries){
 if(!entries.length)return;
 const d=await openFileDB();await new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readwrite');const store=tx.objectStore('files');
  entries.forEach(entry=>store.put(entry));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||Error('Soubor se nepodařilo uložit'));
  tx.onabort=()=>reject(tx.error||Error('Ukládání přílohy bylo přerušeno'));
 });
}
async function fetchStoredBlob(id){
 const d=await openFileDB();return await new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readonly');const r=tx.objectStore('files').get(id);
  r.onsuccess=()=>resolve(r.result?.blob||null);r.onerror=()=>reject(r.error||Error('Nelze načíst přílohu'));
 });
}
async function removeFiles(ids){
 if(!ids.length)return;
 const d=await openFileDB();await new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readwrite');ids.forEach(id=>tx.objectStore('files').delete(id));
  tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||Error('Nepodařilo se smazat přílohu'));
 });
}
const fileAsDataURL=blob=>new Promise((resolve,reject)=>{
 const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);
});
function dataURLtoBlob(url){
 const m=String(url||'').match(/^data:([^;,]*)(;base64)?,(.*)$/s);
 if(!m)throw Error('Původní příloha je poškozená');
 const mime=m[1]||'application/octet-stream';
 if(!m[2])return new Blob([decodeURIComponent(m[3])],{type:mime});
 const s=atob(m[3]);const a=new Uint8Array(s.length);
 for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);
 return new Blob([a],{type:mime});
}
function cleanFilename(name){return (String(name||'soubor').replace(/[\\/:*?"<>|\x00-\x1F]/g,'_').slice(0,120).trim()||'soubor')}
async function downloadBlob(blob,filename,share=false){
 const name=cleanFilename(filename);if(!blob)throw Error('Uloženou přílohu nelze načíst');
 if(window.MojeAutoNative?.saveFile){
  const dataUrl=await fileAsDataURL(blob);
  const result=await window.MojeAutoNative.saveFile({name,dataUrl,share});
  if(!share)notice('Uloženo do Dokumenty / MojeAuto: '+name);
  return result;
 }
 if(share&&navigator.canShare&&navigator.canShare({files:[new File([blob],name,{type:blob.type||'application/octet-stream'})]})){
  await navigator.share({files:[new File([blob],name,{type:blob.type||'application/octet-stream'})],title:name});return;
 }
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;
 a.style.display='none';document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),60000);
 if(window.Capacitor?.isNativePlatform?.())notice('Pokud stahování nefunguje, bude potřeba novější APK s podporou ukládání souborů.');
}
function recordFileMetas(r){
 const files=[...(Array.isArray(r.attachments)?r.attachments:[])];
 if(r.fileData)files.unshift({id:'legacy',name:r.fileName||'puvodni-priloha',kind:r.type==='odo'?'tachometr':'faktura',legacy:true});
 return files;
}
async function recordFileBlob(rec,meta){
 if(meta.legacy||meta.id==='legacy')return dataURLtoBlob(rec.fileData);
 const b=await fetchStoredBlob(meta.id);
 if(!b)throw Error('Příloha nebyla nalezena v telefonu. Obnov ji ze zálohy.');return b;
}
async function saveAttachment(rec,meta,share){
 try{const b=await recordFileBlob(rec,meta);await downloadBlob(b,meta.name,share||!!window.MojeAutoNative?.saveFile)}
 catch(err){alert('Nelze '+(share?'sdílet':'uložit')+' přílohu: '+(err.message||err))}
}

// Náhled uložených dokladů: fotky, PDF přes PDF.js a Excel přes SheetJS.
// Android WebView nemá spolehlivý vlastní PDF prohlížeč, proto PDF vykreslujeme na canvas.
let previewFileUrl=null,previewPdfDocument=null,previewSession=0;
function ensureAttachmentViewer(){
 if($('file-viewer'))return $('file-viewer');
 const d=document.createElement('dialog');d.id='file-viewer';d.setAttribute('aria-label','Náhled dokladu');
 d.innerHTML='<div class="preview-head"><h2 id="preview-title">Náhled přílohy</h2><button type="button" class="close" id="preview-close" aria-label="Zavřít náhled">✕</button></div><div id="preview-status" aria-live="polite" class="hint"></div><div id="preview-toolbar" class="actions" hidden></div><div id="preview-content" class="preview-content"></div><div class="actions end"><button class="secondary" type="button" id="preview-save">⬇ Uložit / sdílet</button><button class="ghost" type="button" id="preview-done">Zavřít</button></div>';
 document.body.appendChild(d);
 $('preview-close').onclick=()=>d.close();$('preview-done').onclick=()=>d.close();
 d.addEventListener('close',()=>{
  previewSession++;
  if(previewFileUrl){URL.revokeObjectURL(previewFileUrl);previewFileUrl=null}
  if(previewPdfDocument){try{previewPdfDocument.destroy()}catch{}previewPdfDocument=null}
  $('preview-content').replaceChildren();$('preview-toolbar').replaceChildren();
 });
 return d;
}
async function previewAttachment(rec,meta){
 const viewer=ensureAttachmentViewer(),area=$('preview-content'),status=$('preview-status'),bar=$('preview-toolbar');
 const seq=++previewSession;
 area.replaceChildren();bar.replaceChildren();bar.hidden=true;
 $('preview-title').textContent=meta.name||'Příloha';status.textContent='Načítám uložený dokument…';
 if(!viewer.open)viewer.showModal();
 $('preview-save').onclick=()=>saveAttachment(rec,meta,true);
 try{
  const blob=await recordFileBlob(rec,meta);
  if(seq!==previewSession||!viewer.open)return;
  const filename=String(meta.name||'').toLowerCase();const mime=blob.type||meta.mime||'';
  if(mime.startsWith('image/')||/\.(jpe?g|png|webp|gif|bmp)$/i.test(filename)){
   previewFileUrl=URL.createObjectURL(blob);
   const img=document.createElement('img');img.className='preview-image';img.alt='Fotografie: '+meta.name;img.src=previewFileUrl;
   img.onerror=()=>{status.textContent='Obrázek se nepodařilo zobrazit. Zkus „Uložit / sdílet“.'};
   area.appendChild(img);status.textContent='Originální uložená fotografie';
  }else if(mime==='application/pdf'||filename.endsWith('.pdf')){
   status.textContent='Načítám PDF prohlížeč…';
   await ensurePdf();
   const pdf=await pdfjsLib.getDocument({data:new Uint8Array(await blob.arrayBuffer())}).promise;
   if(seq!==previewSession||!viewer.open){pdf.destroy();return}
   previewPdfDocument=pdf;let currentPage=1;
   const prev=document.createElement('button'),next=document.createElement('button'),count=document.createElement('span');
   prev.type='button';prev.className='secondary';prev.textContent='← Předchozí';
   next.type='button';next.className='secondary';next.textContent='Další →';count.className='hint';
   bar.append(prev,count,next);bar.hidden=false;
   async function showPage(n){
    currentPage=n;prev.disabled=n<=1;next.disabled=n>=pdf.numPages;
    count.textContent=`Strana ${n} z ${pdf.numPages}`;status.textContent='Zobrazuji stránku…';
    const pg=await pdf.getPage(n),v=pg.getViewport({scale:1}),scale=Math.min(2,1200/v.width);
    const viewport=pg.getViewport({scale}),c=document.createElement('canvas');
    c.width=Math.round(viewport.width);c.height=Math.round(viewport.height);c.className='preview-pdf-page';
    if(seq!==previewSession||!viewer.open)return;
    area.replaceChildren(c);await pg.render({canvasContext:c.getContext('2d'),viewport}).promise;
    if(seq===previewSession)status.textContent='PDF – původní faktura beze změn';
   }
   prev.onclick=()=>showPage(Math.max(1,currentPage-1)).catch(e=>status.textContent='Stránku nelze otevřít: '+e.message);
   next.onclick=()=>showPage(Math.min(pdf.numPages,currentPage+1)).catch(e=>status.textContent='Stránku nelze otevřít: '+e.message);
   await showPage(1);
  }else if(/\.(xlsx|xlsm|xls)$/i.test(filename)){
   if(!sheetReady){await injectScript('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js');sheetReady=true}
   const wb=XLSX.read(await blob.arrayBuffer(),{type:'array',cellDates:true});
   if(seq!==previewSession||!viewer.open)return;
   const tabs=document.createElement('select');tabs.setAttribute('aria-label','List Excelu');
   wb.SheetNames.forEach(n=>{const op=document.createElement('option');op.value=n;op.textContent=n;tabs.appendChild(op)});
   const label=document.createElement('label');label.textContent='List: ';label.appendChild(tabs);bar.appendChild(label);bar.hidden=false;
   function showSheet(name){
    const rows=XLSX.utils.sheet_to_json(wb.Sheets[name],{header:1,raw:false,defval:''});
    const table=document.createElement('table');table.className='preview-table';
    for(const row of rows.slice(0,250)){
     const tr=document.createElement('tr');for(const value of row.slice(0,18)){
      const td=document.createElement('td');td.textContent=String(value??'');tr.appendChild(td)
     }table.appendChild(tr);
    }
    area.replaceChildren(table);
    status.textContent='Excel – zobrazeno '+Math.min(rows.length,250)+' z '+rows.length+' řádků. Celý soubor lze uložit.';
   }
   tabs.onchange=()=>showSheet(tabs.value);if(tabs.value)showSheet(tabs.value);
  }else if(filename.endsWith('.csv')||mime.startsWith('text/')){
   const pre=document.createElement('pre');pre.className='preview-csv';pre.textContent=(await blob.text()).slice(0,30000);
   area.appendChild(pre);status.textContent='Textový náhled – prvních 30 000 znaků';
  }else status.textContent='Tento typ dokumentu nelze přímo zobrazit. Použij „Uložit / sdílet“.';
 }catch(e){if(seq===previewSession)status.textContent='Náhled se nepodařilo načíst: '+(e.message||e)+'. Soubor můžeš zkusit uložit nebo sdílet.'}
}
function storedAttachmentUI(old,removed,onRemove){
 const target=$('stored-files');if(!target)return;
 const metas=recordFileMetas(old).filter(x=>!removed.has(x.id));
 target.innerHTML=metas.length?metas.map(m=>`<div class="saved-file"><div class="file-name">${html(m.kind==='tachometr'?'📸 ':'📄 ')}${html(m.name)}</div><div class="actions"><button type="button" class="primary" data-open="${html(m.id)}">👁 Otevřít</button><button type="button" class="secondary" data-dl="${html(m.id)}">⬇ Uložit</button><button type="button" class="secondary" data-share="${html(m.id)}">Sdílet</button><button type="button" class="ghost" data-rm="${html(m.id)}">Odebrat</button></div></div>`).join(''):'<p class="hint">Zatím žádné uložené přílohy.</p>';
 target.querySelectorAll('[data-open]').forEach(b=>b.onclick=async()=>{const meta=metas.find(m=>m.id===b.dataset.open);if(meta)await previewAttachment(old,meta)});
 target.querySelectorAll('[data-dl]').forEach(b=>b.onclick=async()=>{const meta=metas.find(m=>m.id===b.dataset.dl);if(meta)await saveAttachment(old,meta,false)});
 target.querySelectorAll('[data-share]').forEach(b=>b.onclick=async()=>{const meta=metas.find(m=>m.id===b.dataset.share);if(meta)await saveAttachment(old,meta,true)});
 target.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{const item=metas.find(m=>m.id===b.dataset.rm);removed.add(b.dataset.rm);if(item&&onRemove)onRemove(item);storedAttachmentUI(old,removed,onRemove)});
}
// Lokální JSON záloha obsahuje i bajty všech vícečetných příloh.
async function backupData(){
 const attachments={};
 for(const r of db.records)for(const m of r.attachments||[]){
  const blob=await fetchStoredBlob(m.id);if(!blob)throw Error('Chybí příloha '+m.name+'; nejdřív ji oprav nebo odeber');
  attachments[m.id]=await fileAsDataURL(blob);
 }
 return {format:'mojeauto-v2',cars:db.cars,records:db.records,attachmentBlobs:attachments};
}
function renderCarBiographyButton(){
 if(activeCar&&$('stats')){
  const b=document.createElement('button');b.id='export-bio';b.type='button';b.className='secondary';
  b.textContent='📄 Životopis auta (PDF) – otevřít / uložit';
  const parent=$('stats');if(!parent.querySelector('#export-bio'))parent.appendChild(b);
  b.onclick=()=>exportBiography(activeCar);
 }
}
// Jednoduchý PDF zapisovač: česká diakritika se vykreslí v prohlížeči
// na A4 a fotografie stránek se vloží do PDF. Bez přenosu dat a bez CDN.
function imagePagesToPdf(jpegs,width,height){
 const encoder=new TextEncoder(),chunks=[],offsets=[];let length=0;
 function append(data){const arr=typeof data==='string'?encoder.encode(data):data;chunks.push(arr);length+=arr.length;}
 function begin(id){offsets[id]=length;append(`${id} 0 obj\n`)}
 function end(){append('\nendobj\n')}
 append('%PDF-1.4\n');
 begin(1);append('<< /Type /Catalog /Pages 2 0 R >>');end();
 begin(2);append(`<< /Type /Pages /Count ${jpegs.length} /Kids [${jpegs.map((_,i)=>3+3*i+' 0 R').join(' ')}] >>`);end();
 for(let i=0;i<jpegs.length;i++){
  const pageId=3+3*i,imgId=pageId+1,contentId=pageId+2;
  const raw=atob(jpegs[i].split(',')[1]),image=new Uint8Array(raw.length);
  for(let j=0;j<raw.length;j++)image[j]=raw.charCodeAt(j);
  begin(pageId);append(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 ${imgId} 0 R >> >> /Contents ${contentId} 0 R >>`);end();
  begin(imgId);append(`<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${image.length} >>\nstream\n`);
  append(image);append('\nendstream');end();
  const content='q\n595.28 0 0 841.89 0 0 cm\n/Im0 Do\nQ\n';
  begin(contentId);append(`<< /Length ${encoder.encode(content).length} >>\nstream\n${content}endstream`);end();
 }
 const xref=length;append(`xref\n0 ${offsets.length}\n0000000000 65535 f \n`);
 for(let i=1;i<offsets.length;i++)append(`${String(offsets[i]).padStart(10,'0')} 00000 n \n`);
 append(`trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
 return new Blob(chunks,{type:'application/pdf'});
}
async function exportBiography(carId){
 const car=db.cars.find(x=>x.id===carId);if(!car)return notice('Vyber auto');
 const button=$('export-bio');if(button){button.disabled=true;button.textContent='⏳ Připravuji PDF…'}
 await new Promise(resolve=>setTimeout(resolve,20));
 try{
  const pageImages=[];
  const rows=db.records.filter(r=>r.carId===carId).slice().sort((a,b)=>(a.date||'').localeCompare(b.date||''));
  const total=rows.filter(r=>r.type==='service').reduce((sum,r)=>sum+Number(r.price||0),0);
  const maxKm=rows.reduce((m,r)=>Math.max(m,Number(r.km)||0),0);
  // Stránka je vykreslená přes systémový font, proto PDF správně zobrazuje českou diakritiku.
  const c=document.createElement('canvas');c.width=1240;c.height=1754;
  const ctx=c.getContext('2d');const pad=78,usable=c.width-2*pad;
  let y=80,pageNo=0;
  function line(txt,size=23,bold=false,color='#203247',indent=0){
   ctx.font=`${bold?'700':'400'} ${size}px Arial, sans-serif`;ctx.fillStyle=color;
   const words=String(txt||'').split(/\s+/);let l='';
   for(const w of words){const candidate=l?l+' '+w:w;
    if(ctx.measureText(candidate).width>usable-indent&&l){if(y>1620)newPage();ctx.fillText(l,pad+indent,y);y+=size*1.4;l=w;}
    else l=candidate;
   }
   if(l){if(y>1620)newPage();ctx.fillText(l,pad+indent,y);y+=size*1.4;}
  }
  function newPage(){
   if(pageNo>0)pageImages.push(c.toDataURL('image/jpeg',.86));
   pageNo++;ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);
   ctx.fillStyle='#123d62';ctx.fillRect(0,0,c.width,18);
   ctx.font='18px Arial, sans-serif';ctx.fillStyle='#6b7c90';ctx.fillText('MOJE AUTO • SERVISNÍ HISTORIE',pad,1712);y=80;
  }
  newPage();line('ŽIVOTOPIS AUTA',41,true,'#123d62');y+=10;
  line(`${car.brand||''} ${car.model||''}`,34,true);line(`SPZ: ${car.plate||'—'}   VIN: ${car.vin||'—'}`);
  line(`Rok výroby: ${car.year||'—'}   Vygenerováno: ${date(today())}`,20);
  y+=16;line(`Stav km v historii: ${maxKm?maxKm.toLocaleString('cs-CZ')+' km':'neuvedeno'}`,25,true);
  line(`Celkové servisní náklady včetně DPH: ${money(total)}`,25,true);y+=20;
  line(`SERVISNÍ UDÁLOSTI (${rows.length})`,29,true,'#123d62');y+=14;
  if(!rows.length)line('Zatím žádný servisní záznam.');
  for(const [i,r] of rows.entries()){
   if(y>1470)newPage();
   line(`${i+1}. ${date(r.date)} — ${r.title||'Servis'}`,25,true,'#1e4c72');
   line(`Kilometry: ${r.km?Number(r.km).toLocaleString('cs-CZ')+' km':'—'}   Moje náklady: ${r.type==='service'?money(r.price):'—'}`,20);
   if(r.type==='service'&&Array.isArray(r.excludedItems)&&r.excludedItems.length){
    line('Faktury celkem s DPH: '+money(r.invoiceTotal??r.price),18);
    for(const item of r.excludedItems)line('Nezapočítáno: '+item.title+' (−'+money(item.amount)+')',18,false,'#526174',12);
   }
   if(r.type==='service'&&(r.priceWithoutVat||r.vatAmount))line(`Bez DPH: ${r.priceWithoutVat!==''&&r.priceWithoutVat!=null?money(r.priceWithoutVat):'—'}   DPH: ${r.vatAmount!==''&&r.vatAmount!=null?money(r.vatAmount):'—'}`,19);
   if(r.note)line('Poznámka: '+r.note,19,false,'#34495e');
   const files=recordFileMetas(r);
   if(files.length){line('Přílohy:',19,true);for(const m of files)line('• '+m.name+(m.kind==='tachometr'?' (tachometr)':''),18,false,'#34495e',15);}
   y+=18;
  }
  pageImages.push(c.toDataURL('image/jpeg',.86));
  const blob=imagePagesToPdf(pageImages,c.width,c.height);
  // Android WebView často ukládá soubory do skryté složky aplikace.
  // Systémová nabídka sdílení dovolí vybrat Uložit do souborů, Disk atd.
  await downloadBlob(blob,`Zivotopis_${car.brand}_${car.model}_${car.plate||'auto'}.pdf`,!!window.MojeAutoNative?.saveFile);
 }catch(err){alert('Nepodařilo se vytvořit PDF: '+(err.message||err))}
 finally{if(button){button.disabled=false;button.textContent='📄 Životopis auta (PDF) – otevřít / uložit'}}
}

function setupPhotoTools(old,isOdo,removed=new Set()){
 const inp=$('photo-upload'),canvas=$('redact-canvas'),wrap=$('redact-tools'),ctx=canvas.getContext('2d');
 const odoCanvas=isOdo?$('odo-select-canvas'):null,odoWrap=isOdo?$('odo-select-tools'):null;
 let image=null,rects=[],begin=null,removeOld=false;
 let odoView=[0,.30,1,.70],odoRect=null,odoBegin=null;
 function repaint(){if(!image)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);ctx.fillStyle='#000';rects.forEach(r=>ctx.fillRect(r.x,r.y,r.w,r.h))}
 function point(ev,c){const b=c.getBoundingClientRect();return{x:(ev.clientX-b.left)*c.width/b.width,y:(ev.clientY-b.top)*c.height/b.height}}
 // Začernění faktury je nezávislé na výběru oblasti pro OCR tachometru.
 canvas.onpointerdown=e=>{if(!image)return;begin=point(e,canvas);canvas.setPointerCapture(e.pointerId)};
 canvas.onpointerup=e=>{if(!begin)return;const end=point(e,canvas),r={x:Math.min(begin.x,end.x),y:Math.min(begin.y,end.y),w:Math.abs(begin.x-end.x),h:Math.abs(begin.y-end.y)};if(r.w>6&&r.h>6)rects.push(r);begin=null;repaint()};
 $('redact-undo').onclick=()=>{rects.pop();repaint()};$('redact-reset').onclick=()=>{rects=[];repaint()};
 function repaintOdo(){if(!image||!odoCanvas)return;
  const c=odoCanvas.getContext('2d'),[x,y,w,h]=odoView;
  const iw=image.naturalWidth||image.width,ih=image.naturalHeight||image.height;
  c.drawImage(image,iw*x,ih*y,iw*w,ih*h,0,0,odoCanvas.width,odoCanvas.height);
  const r=odoRect||odoBegin;
  if(r){c.fillStyle='rgba(36,153,230,.18)';c.strokeStyle='#27d5ff';c.lineWidth=4;
   const a=(r.x-x)/w*odoCanvas.width,b=(r.y-y)/h*odoCanvas.height,d=r.w/w*odoCanvas.width,e=r.h/h*odoCanvas.height;
   c.fillRect(a,b,d,e);c.strokeRect(a,b,d,e)}
 }
 function odoPoint(ev){const v=point(ev,odoCanvas),[x,y,w,h]=odoView;return{x:x+v.x/odoCanvas.width*w,y:y+v.y/odoCanvas.height*h}}
 function odoSelection(start,end){const [x,y,w,h]=odoView;const l=Math.max(x,Math.min(start.x,end.x)),t=Math.max(y,Math.min(start.y,end.y));return{x:l,y:t,w:Math.min(x+w,Math.max(start.x,end.x))-l,h:Math.min(y+h,Math.max(start.y,end.y))-t}}
 if(odoCanvas){
  odoCanvas.onpointerdown=e=>{if(!image)return;odoCanvas.setPointerCapture(e.pointerId);odoBegin={start:odoPoint(e),current:odoPoint(e)};odoRect=null};
  odoCanvas.onpointermove=e=>{if(!odoBegin)return;odoBegin.current=odoPoint(e);const temp=odoSelection(odoBegin.start,odoBegin.current);odoRect=temp;repaintOdo()};
  odoCanvas.onpointerup=e=>{if(!odoBegin)return;const r=odoSelection(odoBegin.start,odoPoint(e));odoBegin=null;odoRect=r.w>=.018&&r.h>=.012?r:null;$('odo-read-selected').disabled=!odoRect;repaintOdo()};
  odoCanvas.onpointercancel=()=>{odoBegin=null;repaintOdo()};
  $('odo-view-toggle').onclick=()=>{odoView=odoView[1]===0?[0,.30,1,.70]:[0,0,1,1];odoRect=null;$('odo-read-selected').disabled=true;$('odo-view-toggle').textContent=odoView[1]===0?'Zobrazit spodní část':'Zobrazit celý snímek';repaintOdo()};
 }
 $('remove-attachment').onclick=()=>{removeOld=true;inp.value='';image=null;rects=[];odoRect=null;wrap.hidden=true;if(odoWrap)odoWrap.hidden=true;$('attached').textContent='Příloha bude odstraněna při uložení.'};
 async function loadImage(file){const u=URL.createObjectURL(file);try{const im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=u});image=im;
  const scale=Math.min(1,1400/im.width,1400/im.height);canvas.width=Math.max(1,Math.round(im.width*scale));canvas.height=Math.max(1,Math.round(im.height*scale));rects=[];wrap.hidden=isOdo;repaint();
  if(odoCanvas){odoView=[0,.30,1,.70];odoRect=null;odoCanvas.width=Math.min(1200,im.width);odoCanvas.height=Math.max(1,Math.round(odoCanvas.width*im.height*.70/im.width));odoWrap.hidden=false;$('odo-read-selected').disabled=true;$('odo-view-toggle').textContent='Zobrazit celý snímek';repaintOdo()}
 }finally{URL.revokeObjectURL(u)}}
 inp.onchange=async()=>{const f=inp.files[0];if(!f)return;removeOld=false;const isImg=f.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(f.name);if(isImg){try{await loadImage(f)}catch{notice('Fotografii nelze otevřít')}}else{image=null;wrap.hidden=true;if(odoWrap)odoWrap.hidden=true} $('attached').textContent='Nová příloha: '+f.name;if(isOdo&&isImg&&image)doOCR();};
 async function doOCR(box=null){
  const saved=[];
  if(!isOdo)for(const m of recordFileMetas(old).filter(m=>m.kind!=='tachometr'&&!removed.has(m.id))){
   const blob=await recordFileBlob(old,m);saved.push(new File([blob],m.name,{type:m.mime||blob.type}));
  }
  const fresh=[...(inp.files.length?[inp.files[0]]:[]),...(!isOdo&&$('extra-files')?[...$('extra-files').files]:[])];
  const sources=[...saved,...fresh],f=isOdo?inp.files[0]:sources[0];
  if(!f){notice('Nejdříve přilož fotografii, PDF nebo Excel');return}

  const btn=$('run-ocr'),selectedBtn=isOdo?$('odo-read-selected'):null;btn.disabled=true;if(selectedBtn)selectedBtn.disabled=true;
  try{$('ocr-progress').textContent='Načítám čtení dokladů…';
   const isImg=f.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(f.name);
   if(isOdo&&isImg){const out=await readOdometer(f,s=>$('ocr-progress').textContent=s,box);
    $('ocr-text').value=out.text;
    if(out.km)$('rec-km').value=out.km;
    $('ocr-progress').textContent=out.reliable?'✅ Odečteno '+Number(out.km).toLocaleString('cs-CZ')+' km. Zkontroluj číslo na fotografii před uložením.':
      (out.suggestion?'⚠️ Nejistý odečet: možná '+Number(out.suggestion).toLocaleString('cs-CZ')+' km. Zkontroluj a doplň počet km ručně.':'⚠️ Kilometry se nepodařilo bezpečně určit. Označ prstem na fotografii jen číslice a klikni na „Přečíst označené km“.');
   }else{
    let totalGross=0,totalNet=0,totalVat=0,allGross=true,allNet=true,allVat=true,combined=[],detectedItems=[];
    let anyGross=false,first=null;
    for(let i=0;i<sources.length;i++){
     const current=sources[i];$('ocr-progress').textContent=`Čtu fakturu ${i+1}/${sources.length}: ${current.name}…`;
     const txt=await readDocument(current,s=>$('ocr-progress').textContent=`${current.name}: ${s}`),data=extractFields(txt);
     first ||= data;
     detectedItems.push(...findInvoiceRows(txt,current.name));
     const moneyText=data.price!==''?Number(data.price).toLocaleString('cs-CZ')+' Kč (vč. DPH)':'⚠️ cena včetně DPH nenalezena';
     combined.push(`=== ${current.name} ===\n${txt}\n--- Výsledek: ${moneyText}${data.calculated?' (součet základu a uvedené DPH)':''} ---`);
     if(data.price==='')allGross=false;else{totalGross+=Number(data.price);anyGross=true}
     if(data.priceWithoutVat==='')allNet=false;else totalNet+=Number(data.priceWithoutVat);
     if(data.vatAmount==='')allVat=false;else totalVat+=Number(data.vatAmount);
    }
    $('ocr-text').value=combined.join('\n\n');
    mergeScannedInvoiceRows(detectedItems);
    updatePriceSummary();
    if(first?.date)$('rec-date').value=first.date;
    if(first?.km)$('rec-km').value=first.km;
    if(first?.title&&!$('rec-title').value)$('rec-title').value=first.title;
    if(allGross&&anyGross){$('rec-invoice-total').value=(Math.round(totalGross*100)/100).toFixed(2);updatePriceSummary()}
    if(allNet&&sources.length)$('rec-net').value=(Math.round(totalNet*100)/100).toFixed(2);
    if(allVat&&sources.length)$('rec-vat').value=(Math.round(totalVat*100)/100).toFixed(2);
    $('ocr-progress').textContent=allGross&&anyGross?
     `✅ Načteno ${sources.length} dokladů, celkem s DPH: ${money(totalGross)}. Ověř částku před uložením.`:
     '⚠️ Některý doklad obsahuje jen cenu bez DPH nebo nemá čitelnou částku. Součet s DPH jsem nepřepsal, doplň ho ručně.';
    if(detectedItems.length)$('invoice-rows-list').scrollIntoView({behavior:'smooth',block:'start'});
    else $('ocr-progress').textContent+=' Položky se nerozpoznaly – zkontroluj přepis nebo použij ruční zadání.';
   }
  }catch(e){$('ocr-progress').textContent='Chyba: '+e.message}finally{btn.disabled=false;if(selectedBtn)selectedBtn.disabled=!odoRect}
 }
 $('run-ocr').onclick=()=>doOCR();
 if(isOdo)$('odo-read-selected').onclick=()=>{
  if(!odoRect)return;
  // Výběr mírně rozšíříme, aby nedošlo k odříznutí krajních číslic.
  const x=Math.max(0,odoRect.x-.014),y=Math.max(0,odoRect.y-.013);
  doOCR([x,y,Math.min(1-x,odoRect.w+.028),Math.min(1-y,odoRect.h+.026)]);
 };
 return {async attachment(){
  const file=inp.files[0];if(!file)return null;
  if(file.size>25*1024*1024)throw Error('Příloha je větší než 25 MB.');
  // Původní fotografii zachováme, dokud uživatel skutečně něco nezačerní.
  if(image&&rects.length){repaint();const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Obrázek nelze uložit')),'image/jpeg',.90));
   return new File([blob],file.name.replace(/\.[^.]+$/,'')+'-zacerneno.jpg',{type:'image/jpeg'});
  }
  return file;
 }};
}

function addExcludedRow(item={}){
 const list=$('excluded-items-list');if(!list)return;
 const row=document.createElement('div');row.className='excluded-row';
 row.innerHTML=`<label>Nezapočítat položku<input type="text" class="excluded-title" placeholder="Např. filtr do jiného auta" value="${html(item.title??'')}"></label><label>Částka s DPH (Kč)<input type="number" min="0" step="0.01" inputmode="decimal" class="excluded-amount" value="${html(item.amount??'')}"></label><button class="ghost excluded-remove" type="button" aria-label="Odebrat položku">✕</button>`;
 list.appendChild(row);
 row.querySelector('.excluded-remove').onclick=()=>{row.remove();updatePriceSummary()};
 row.querySelectorAll('input').forEach(input=>input.addEventListener('input',updatePriceSummary));
}
function excludedRows(){return [...document.querySelectorAll('#excluded-items-list .excluded-row')].map(row=>({
 title:row.querySelector('.excluded-title').value.trim(),amount:row.querySelector('.excluded-amount').value
})).filter(x=>x.title||String(x.amount).trim());}
function updatePriceSummary(){
 if(!$('rec-invoice-total'))return;
 $('exclusion-error').hidden=true;
 const grossRaw=$('rec-invoice-total').value;
 try{
  const price=computeInvoiceShare(grossRaw,[...excludedRows(),...selectedInvoiceRows()]);
  $('invoice-sum').textContent=price.gross===''?'—':money(price.gross);
  $('excluded-sum').textContent=money(price.excluded);
  $('my-cost').textContent=price.own===''?'—':money(price.own);
  $('rec-price').value=price.own===''?'':price.own.toFixed(2);
 }catch(e){
  $('rec-price').value='';$('my-cost').textContent='Nelze vypočítat';
  $('invoice-sum').textContent=grossRaw?money(grossRaw):'—';$('excluded-sum').textContent='—';
  $('exclusion-error').hidden=false;$('exclusion-error').textContent=e.message;
 }
}
function openRecord(id,type='service'){
 if(!db.cars.length){notice('Nejdřív přidej auto');showTab('overview');return}
 const old=db.records.find(r=>r.id===id)||{},isOdo=(old.type||type)==='odo';
 const cs=db.cars.map(c=>`<option value="${html(c.id)}" ${(old.carId||activeCar)===c.id?'selected':''}>${html(c.brand+' '+c.model)}</option>`).join('');
 const priorInvoiceTotal=old.invoiceTotal??old.price??'';
 const vatFields=isOdo?'':`<div class="price-fields">${old.type==='service'&&old.priceWithoutVat===undefined&&Number(old.price)>0?'<p class="warning">Starší záznam: dřívější OCR mohlo uložit cenu bez DPH. Zkontroluj faktury.</p>':''}<label>Cena faktur bez DPH (Kč)<input id="rec-net" name="priceWithoutVat" type="number" step="0.01" min="0" value="${html(old.priceWithoutVat??'')}"></label><label>DPH na fakturách (Kč)<input id="rec-vat" name="vatAmount" type="number" step="0.01" min="0" value="${html(old.vatAmount??'')}"></label><label><strong>Faktury celkem včetně DPH (Kč)</strong><input id="rec-invoice-total" name="invoiceTotal" type="number" step="0.01" min="0" value="${html(priorInvoiceTotal)}"></label><button type="button" class="secondary" id="sum-vat">Spočítat součet bez DPH + DPH</button><div class="excluded-box"><h3>✅ Klepni na položky, které nebyly pro tvoje auto</h3><p class="hint">Aplikace je vypíše z faktur po načtení. <b>Zaškrtni jen cizí položky</b>; jejich ceny včetně DPH se automaticky odečtou. Původní faktura zůstane beze změny.</p><div id="invoice-rows-list" class="invoice-rows-list"></div><p id="invoice-rows-status" class="hint" aria-live="polite"></p><button type="button" id="rebuild-invoice-rows" class="secondary">🔎 Vypsat položky z rozpoznaného textu</button><details class="manual-exclusion"><summary>Pokud OCR položku nenašlo: zadat ručně</summary><div id="excluded-items-list"></div><button type="button" id="add-excluded-item" class="secondary">＋ Přidat cizí položku ručně</button></details><p id="exclusion-error" class="warning" role="alert" hidden></p></div><div class="price-summary"><div>Faktury včetně DPH <b id="invoice-sum">—</b></div><div>Nezapočítané položky <b id="excluded-sum">—</b></div><div class="own-cost">Moje náklady na auto <b id="my-cost">—</b></div></div><label><strong>Do servisních nákladů auta se uloží</strong><input id="rec-price" name="price" type="number" step="0.01" readonly value="${html(old.price??'')}"></label><p class="hint">Započítá se jen část za tvoje auto, nikoliv celá společná faktura. Cena se počítá automaticky.</p></div>`;
 const serviceOdo=isOdo?'':`<div class="panel compact"><h3>📸 Tachometr při servisu</h3><label>Přiložit fotografii tachometru<input type="file" id="service-odo-upload" accept="image/*"></label><button id="service-odo-read" type="button" class="secondary">🔎 Načíst km z fotografie</button><p id="service-odo-progress" class="hint">Fotografie se uloží ke stejnému servisnímu záznamu.</p></div>`;
 const extraFiles=isOdo?'':`<label>Další faktury / doklady ke stejnému servisu<input id="extra-files" type="file" multiple accept="image/*,.pdf,.xlsx,.xls,.xlsm,.csv,application/pdf"></label><p class="hint">Můžeš vybrat několik PDF, obrázků nebo Excelů najednou. Každý dokument se uloží a bude samostatně ke stažení.</p><div id="new-files-list" class="filelist"></div>`;
 const content=`<label>Auto<select name="carId">${cs}</select></label><label>Datum<input id="rec-date" type="date" name="date" required value="${html(old.date||today())}"></label><label>Název záznamu<input id="rec-title" name="title" required value="${html(old.title||(isOdo?'Stav tachometru':''))}" placeholder="Výměna oleje, brzdy…"></label><label>Kilometry<input id="rec-km" name="km" type="number" min="0" ${isOdo?'required':''} inputmode="numeric" value="${html(old.km??'')}"></label>${vatFields}<label>Poznámky<textarea name="note" rows="3">${html(old.note||'')}</textarea></label>${serviceOdo}<label>${isOdo?'Fotografie tachometru':'Faktura pro OCR a případné začernění'}<input name="photo" id="photo-upload" type="file" accept="${isOdo?'image/*':'image/*,.pdf,.xlsx,.xls,.xlsm,.csv,application/pdf'}"></label>${extraFiles}<button type="button" id="run-ocr" class="secondary read-btn">🔎 ${isOdo?'Přečíst kilometry':'Přečíst všechny faktury (i uložené)'}</button><div id="ocr-progress" aria-live="polite">Čtení spustíš po nahrání. Vyžaduje internet při načtení OCR.</div>${isOdo?`<div id="odo-select-tools" hidden><p><b>📍 Přesnější načtení kilometrů</b></p><p class="hint">Pokud se km nepřečtou, prstem označ na fotografii jen číslice.</p><canvas id="odo-select-canvas" style="width:100%;height:auto;border:1px solid #9caec4;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="odo-read-selected" class="secondary" disabled>🔎 Přečíst označené km</button><button type="button" id="odo-view-toggle" class="ghost">Zobrazit celý snímek</button></div></div>`:''}<label>Rozpoznaný text – lze vymazat či opravit<textarea id="ocr-text" name="ocrText" rows="6" placeholder="Text rozpoznaný z faktury">${html(old.ocrText||'')}</textarea></label><div id="redact-tools" hidden><p><b>Začernění údajů na fotografii</b></p><p class="hint">Prstem označ část fotografie ke skrytí. Při začernění se uloží jen upravená verze.</p><canvas id="redact-canvas" style="width:100%;height:auto;border:1px solid #b9c6d7;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="redact-undo" class="secondary">↶ Vrátit poslední</button><button type="button" id="redact-reset" class="ghost">Zrušit začernění</button></div></div><div class="actions"><button type="button" class="ghost" id="remove-attachment">🗑 Odebrat nově vybranou přílohu</button></div><div id="attached" class="note">Vybraný soubor není</div><h3>Uložené faktury a fotografie</h3><div id="stored-files"></div><p class="warning">Položky i ceny z OCR jsou návrh a mohou být nepřesné; částky včetně DPH vždy ověř podle originálu. Začernění originálního PDF nebo Excelu nepodporujeme; u těchto souborů upravíš jen přepis.</p>`;
 let tools;const removed=new Set();
 modal(id?'Upravit záznam':(isOdo?'Nový stav tachometru':'Nová servisní událost'),content,async f=>{
  const submit=$('editor-form').querySelector('[type=submit]');submit.disabled=true;
  let entries=[];
  try{
   const manualItems=isOdo?[]:excludedRows();
   const selectedItems=isOdo?[]:selectedInvoiceRows();
   const totals=isOdo?{gross:'',excluded:0,own:''}:computeInvoiceShare(f.get('invoiceTotal'),[...manualItems,...selectedItems]);
   const nonCarItems=isOdo?[]:[...manualItems.map(item=>({title:item.title,amount:amountInCents(item.amount)/100})),
    ...selectedItems.map(item=>({title:item.title,amount:Math.round(item.amount*100)/100,sourceKey:item.sourceKey,source:item.source}))];
   const primary=await tools.attachment();
   const pending=[];
   if(primary)pending.push({file:primary,kind:isOdo?'tachometr':'faktura'});
   if(!isOdo){
    const odoPhoto=$('service-odo-upload').files[0];if(odoPhoto)pending.push({file:odoPhoto,kind:'tachometr'});
    for(const file of $('extra-files').files)pending.push({file,kind:'faktura'});
   }
   if(pending.some(x=>x.file.size>25*1024*1024))throw Error('Jedna příloha může mít nejvýše 25 MB.');
   entries=pending.map(x=>{const id=uid();return {id,blob:x.file,meta:{id,name:x.file.name,kind:x.kind,mime:x.file.type||'application/octet-stream',size:x.file.size}}});
   await writeFiles(entries.map(({id,blob})=>({id,blob})));
   const kept=recordFileMetas(old).filter(m=>!m.legacy&&!removed.has(m.id));
   const net=Number(f.get('priceWithoutVat')),vat=Number(f.get('vatAmount'));
   const record={id:id||uid(),type:isOdo?'odo':'service',carId:f.get('carId'),date:f.get('date'),title:f.get('title').trim(),km:f.get('km'),
    price:isOdo?0:totals.own,invoiceTotal:isOdo?'':totals.gross,excludedItems:nonCarItems,
    invoiceItems:isOdo?[]:workingInvoiceRows.map(x=>({key:x.key,source:x.source,title:x.title,amount:x.amount,excluded:!!x.excluded,estimate:!!x.estimate,raw:x.raw})),
    priceWithoutVat:isOdo?'':(f.get('priceWithoutVat')===''?'':net),
    vatAmount:isOdo?'':(f.get('vatAmount')===''?'':vat),note:f.get('note').trim(),ocrText:f.get('ocrText').trim(),
    fileData:removed.has('legacy')?'':(old.fileData||''),fileName:removed.has('legacy')?'':(old.fileName||''),
    attachments:[...kept,...entries.map(e=>e.meta)]};
   if(!isOdo&&record.price===''&&record.priceWithoutVat!==''){
    if(!confirm('Není zadána cena včetně DPH. Uložit záznam bez započtení částky do nákladů?')){
     await removeFiles(entries.map(e=>e.id));return;
    }
   }
   const before=db.records;
   db.records=id?db.records.map(r=>r.id===id?record:r):[...db.records,record];
   if(!save()){db.records=before;await removeFiles(entries.map(e=>e.id));return;}
   const toDelete=[...removed].filter(x=>x!=='legacy');
   try{await removeFiles(toDelete)}catch(e){console.warn('Úklid souborů:',e)}
   close();notice('Servis a přílohy uloženy');
  }catch(err){try{await removeFiles(entries.map(e=>e.id))}catch{}alert('Uložení se nezdařilo: '+(err.message||err))}
  finally{submit.disabled=false}
 },id?async()=>{
  const before=db.records;db.records=db.records.filter(r=>r.id!==id);
  if(!save()){db.records=before;return false;}
  await removeFiles((old.attachments||[]).map(x=>x.id));return true;
 }:null);
 storedAttachmentUI(old,removed,meta=>{
  workingInvoiceRows=workingInvoiceRows.filter(x=>x.source!==meta.name);
  renderInvoiceRowPicker();updatePriceSummary();
 });
 tools=setupPhotoTools(old,isOdo,removed);
 workingInvoiceRows=isOdo?[]:(Array.isArray(old.invoiceItems)?old.invoiceItems.map(item=>({...item})):
  invoiceRowsFromSavedText(old.ocrText||'').map(item=>({...item,excluded:(old.excludedItems||[]).some(o=>o.sourceKey===item.key)})));
 if(!isOdo){
  $('sum-vat').onclick=()=>{
   const n=$('rec-net').value,v=$('rec-vat').value;
   if(n===''||v===''){notice('Vyplň nejdříve základ i částku DPH.');return}
   $('rec-invoice-total').value=(Math.round((Number(n)+Number(v))*100)/100).toFixed(2);updatePriceSummary();
  };
  $('add-excluded-item').onclick=()=>addExcludedRow();
  for(const item of (Array.isArray(old.excludedItems)?old.excludedItems:[]).filter(item=>!item.sourceKey))addExcludedRow(item);
  renderInvoiceRowPicker();
  $('rebuild-invoice-rows').onclick=()=>{
   const parsed=invoiceRowsFromSavedText($('ocr-text').value);
   mergeScannedInvoiceRows(parsed);
   notice(parsed.length?`Rozpoznáno ${parsed.length} položek. Klepni na ty, které nepatří k autu.`:'Z přepisu se nepodařilo bezpečně najít položky. Zkus znovu načíst fakturu.');
   updatePriceSummary();
  };
  $('rec-invoice-total').addEventListener('input',updatePriceSummary);updatePriceSummary();
  const other=$('extra-files');
  other.onchange=()=>{$('new-files-list').textContent=[...other.files].map(f=>f.name).join(' • ')};
  $('service-odo-read').onclick=async()=>{
   const file=$('service-odo-upload').files[0];if(!file){notice('Vyber fotografii tachometru');return}
   const status=$('service-odo-progress');try{status.textContent='Rozpoznávám…';
    const result=await readOdometer(file,s=>status.textContent=s);
    if(result.km)$('rec-km').value=result.km;
    status.textContent=result.reliable?'✅ Rozpoznáno '+Number(result.km).toLocaleString('cs-CZ')+' km. Ověř na snímku.':
      '⚠️ Nejistý odečet '+(result.suggestion||'')+'. Zadej km podle fotografie ručně.';
   }catch(e){status.textContent='Chyba: '+e.message}
  };
 }
}
$('add-invoice').onclick=()=>openRecord(null,'service');$('add-service').onclick=()=>openRecord(null,'service');$('add-odo').onclick=()=>openRecord(null,'odo');$('history-add').onclick=()=>openRecord(null,'service');
$('export').onclick=async()=>{
 const b=$('export');b.disabled=true;
 try{const json=await backupData();await downloadBlob(new Blob([JSON.stringify(json)],{type:'application/json'}),'moje-auto-zaloha-'+today()+'.json')}
 catch(e){alert('Zálohu nelze vytvořit: '+(e.message||e))}finally{b.disabled=false}
};
$('import-button').onclick=()=>$('import-file').click();
$('import-file').onchange=async e=>{
 try{const file=e.target.files?.[0];if(!file)return;const x=JSON.parse(await file.text());
  if(!Array.isArray(x.cars)||!Array.isArray(x.records))throw Error('Nesprávný formát zálohy');
  if(!confirm('Obnovit zálohu? Aktuální záznamy budou nahrazeny.'))return;
  const stored=[];
  for(const [id,dataUrl] of Object.entries(x.attachmentBlobs||{})){
   if(!/^[a-z\d-]{5,80}$/i.test(id))throw Error('Neplatný identifikátor přílohy');
   stored.push({id,blob:dataURLtoBlob(dataUrl)});
  }
  await writeFiles(stored);const before=db;db={cars:x.cars,records:x.records};
  if(save()){activeCar=null;render();notice('Záloha obnovena')}else{db=before;throw Error('Nedostatek místa pro záznamy')}
 }catch(err){alert('Zálohu nelze obnovit: '+(err.message||err))}finally{e.target.value=''}
};
$('settings').querySelector('h2').textContent='Nastavení a záloha';$('settings').querySelector('.panel').style.display='none';
render();if(activeCar)attachRecords();
if('serviceWorker'in navigator && location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
