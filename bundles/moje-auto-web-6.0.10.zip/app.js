'use strict';
const $=id=>document.getElementById(id), key='mojeauto_v1';
let db={cars:[],records:[]}, editing=null, activeCar=null;
try{const x=JSON.parse(localStorage.getItem(key)||'null');if(x&&Array.isArray(x.cars)&&Array.isArray(x.records))db=x}catch{}
const save=()=>{try{localStorage.setItem(key,JSON.stringify(db));return true}catch(e){alert('Nepodařilo se uložit. Úložiště telefonu může být plné. Proveď zálohu a zmenši fotografie.');return false}};
const uid=()=>crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random());
const html=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>{const val=Number(n||0);return val.toLocaleString('cs-CZ',{style:'currency',currency:'CZK',minimumFractionDigits:Math.abs(val-Math.round(val))>.0001?2:0,maximumFractionDigits:2})};
const date=d=>d?new Date(d+'T12:00:00').toLocaleDateString('cs-CZ'):'—';
function notice(s){$('toast').textContent=s;setTimeout(()=>$('toast').textContent='',3300)}
function showTab(t){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('active',e.id===t));document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('active',e.dataset.view===t));render()}
document.querySelectorAll('.tab').forEach(e=>e.addEventListener('click',()=>showTab(e.dataset.view)));
const carName=id=>{const c=db.cars.find(x=>x.id===id);return c?`${c.brand} ${c.model}`:'Neznámé auto'};
function render(){const cars=$('car-list');cars.innerHTML=db.cars.length?db.cars.map(c=>`<button class="car ${c.id===activeCar?'selected':''}" data-car="${html(c.id)}"><div><b>🚘 ${html(c.brand)} ${html(c.model)}</b><small>${html(c.plate||'Bez SPZ')} · ${html(c.year||'Rok neuveden')}</small></div><span>✎</span></button>`).join(''):'<div class="panel">Zatím nemáš uložené žádné auto. Začni tlačítkem „Přidat auto“.</div>';
cars.querySelectorAll('[data-car]').forEach(b=>b.onclick=()=>{activeCar=b.dataset.car;render();});
if(!db.cars.some(c=>c.id===activeCar))activeCar=db.cars[0]?.id||null;
$('overview-details').hidden=!activeCar;
if(activeCar){const rs=db.records.filter(r=>r.carId===activeCar);const odo=rs.filter(r=>Number(r.km)>0).sort((a,b)=>Number(b.km)-Number(a.km))[0];$('stats').innerHTML=`<div class="stat"><small>Vybrané auto</small><strong>${html(carName(activeCar))}</strong><button class="secondary" id="edit-car">Upravit auto</button></div><div class="stat"><small>Poslední stav tachometru</small><strong>${odo?Number(odo.km).toLocaleString('cs-CZ')+' km':'—'}</strong></div><div class="stat"><small>Celkové servisní náklady</small><strong>${money(rs.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</strong></div>`;$('edit-car').onclick=()=>openCar(activeCar);$('recent').innerHTML=listRecords(rs.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5));}
$('history-car').innerHTML='<option value="all">Všechna auta</option>'+db.cars.map(c=>`<option value="${html(c.id)}">${html(c.brand+' '+c.model)}</option>`).join('');const selected=$('history-car').dataset.selected||'all';$('history-car').value=[...$('history-car').options].some(o=>o.value===selected)?selected:'all';renderHistory();renderCosts();attachRecords();renderCarBiographyButton();}
function listRecords(rows){if(!rows.length)return'<p class="note">Zatím žádné záznamy.</p>';return rows.map(r=>`<button class="record" data-rec="${html(r.id)}"><div><b>${r.type==='odo'?'📸':'🔧'} ${html(r.title)}</b><small>${html(carName(r.carId))} · ${date(r.date)} ${r.km?'· '+Number(r.km).toLocaleString('cs-CZ')+' km':''}</small></div><b>${r.type==='service'?money(r.price):'›'}</b></button>`).join('')}
function attachRecords(){document.querySelectorAll('[data-rec]').forEach(b=>b.onclick=()=>openRecord(b.dataset.rec))}
function renderHistory(){let rows=db.records;let car=$('history-car').value;if(car!=='all')rows=rows.filter(r=>r.carId===car);let q=$('history-search').value.trim().toLowerCase();if(q)rows=rows.filter(r=>(r.title+' '+r.note+' '+carName(r.carId)).toLowerCase().includes(q));$('history-list').innerHTML=listRecords(rows.slice().sort((a,b)=>b.date.localeCompare(a.date)));attachRecords()}
function renderCosts(){let sum=db.records.filter(r=>r.type==='service').reduce((s,r)=>s+Number(r.price||0),0);$('costs-body').innerHTML=`<div class="stat"><small>Celkové servisní náklady</small><strong>${money(sum)}</strong></div>`+db.cars.map(c=>`<div class="record"><b>${html(c.brand+' '+c.model)}</b><b>${money(db.records.filter(r=>r.carId===c.id&&r.type==='service').reduce((s,r)=>s+Number(r.price||0),0))}</b></div>`).join('')}
$('history-car').onchange=()=>{$('history-car').dataset.selected=$('history-car').value;renderHistory()};$('history-search').oninput=renderHistory;
function modal(title,body,onSubmit,onDelete){$('editor-title').textContent=title;$('editor-fields').innerHTML=body;$('editor').showModal();$('editor-form').onsubmit=e=>{e.preventDefault();onSubmit(new FormData(e.currentTarget))};$('delete-item').hidden=!onDelete;$('delete-item').onclick=async()=>{if(confirm('Opravdu smazat?')){try{const done=await onDelete();if(done!==false){$('editor').close();render()}}catch(err){alert('Smazání se nezdařilo: '+err.message)}}}}
function close(){ $('editor').close();render() }$('close-dialog').onclick=close;$('cancel-dialog').onclick=close;
function openCar(id){const c=db.cars.find(x=>x.id===id)||{};modal(id?'Upravit auto':'Přidat auto',`<label>Značka<input name="brand" required value="${html(c.brand||'')}"></label><label>Model<input name="model" required value="${html(c.model||'')}"></label><label>SPZ<input name="plate" value="${html(c.plate||'')}"></label><label>Rok výroby<input name="year" inputmode="numeric" value="${html(c.year||'')}"></label><label>VIN (volitelné)<input name="vin" value="${html(c.vin||'')}"></label>`,f=>{const x={id:id||uid(),brand:f.get('brand').trim(),model:f.get('model').trim(),plate:f.get('plate').trim(),year:f.get('year').trim(),vin:f.get('vin').trim()};if(id)db.cars=db.cars.map(z=>z.id===id?x:z);else db.cars.push(x);activeCar=x.id;if(save())close()},id?async()=>{const oldCars=db.cars,oldRecords=db.records;db.cars=db.cars.filter(c=>c.id!==id);db.records=db.records.filter(r=>r.carId!==id);if(!save()){db.cars=oldCars;db.records=oldRecords;return false}try{await removeFiles(oldRecords.filter(r=>r.carId===id).flatMap(r=>(r.attachments||[]).map(a=>a.id)))}catch(e){console.warn(e)}return true}:null)}
$('add-car').onclick=()=>openCar();
const today=()=>new Date().toLocaleDateString('sv-SE');
// OCR běží přímo v prohlížeči, bez odesílání fotografie na server.
const injectScript=(url)=>new Promise((ok,no)=>{const s=document.createElement('script');s.src=url;s.onload=ok;s.onerror=()=>no(Error('Nepodařilo se načíst OCR knihovnu. Zkontroluj internet.'));document.head.appendChild(s)});
let ocrReady=false,pdfReady=false;
async function ocrImage(file,onProgress){if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}const worker=await Tesseract.createWorker('ces+eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení textu: '+Math.round((e.progress||0)*100)+' %')}});try{const r=await worker.recognize(file);return r.data.text}finally{await worker.terminate()}}
// Tachometr V6.1: světlé číslice na tmavém displeji převedeme na černé číslice
// na bílém podkladu. Když automatika selže, lze vybrat prstem jen oblast kilometrů.
function odometerCandidates(text,job,confidence=0){
 const rows=String(text||'').replace(/[|]/g,'1').split(/\r?\n/).map(s=>s.trim()).filter(Boolean),found=[];
 for(let i=0;i<rows.length;i++){
  let line=rows[i];
  // I / l uvnitř čísla bývá na displeji OCR často zaměněné za jedničku.
  line=line.replace(/(?<=[\d\s])[Il](?=\d)/g,'1').replace(/(?<=\d)[Il](?=\s|$)/g,'1').replace(/(?<=\d)[OoQ](?=\d)/g,'0');
  const hasKm=/\b(?:km|kms|odo|odometer)\b/i.test(line)||/\bkm\b/i.test(rows[i-1]||'')||/\bkm\b/i.test(rows[i+1]||'');
  const hasTrip=/\b(?:trip|denn[ií]|daily)\b/i.test(line);
  // Datum, hodiny a denní počítadlo nesmějí soutěžit s celkovými kilometry.
  const cleaned=line
   .replace(/\b[0-3]?\d[.\/-][01]?\d[.\/-](?:20)?\d{2,4}\b/g,' ')
   .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g,' ')
   .replace(/\b(?:trip|denn[ií]|daily)\s*[:=]?\s*\d+(?:[.,]\d+)?\b/gi,' ');
  for(const match of cleaned.matchAll(/(?<!\d)\d(?:[ \u00a0\u202f.]?\d){2,8}(?!\d)/g)){
   const digits=match[0].replace(/\D/g,'');
   if(digits.length<3||digits.length>7)continue;
   if(!hasKm&&!job.manual&&Number(digits)<10000)continue;
   if(hasTrip&&!hasKm&&!job.manual)continue;
   const n=Number(digits);
   if(n<1||n>9999999)continue;
   const weight=job.weight+(hasKm?7:0)+(digits.length>=5?2:0)+(Math.min(4,Math.max(0,confidence)/25));
   found.push({n,weight,conf:confidence,hasKm,manual:!!job.manual,focus:!!job.focus});
  }
 }
 return found;
}
function odometerImage(img,box,mode='bright'){
 const width=img.width,height=img.height;
 let [x,y,w,h]=box;
 x=Math.max(0,Math.min(.99,x));y=Math.max(0,Math.min(.99,y));
 w=Math.max(.015,Math.min(1-x,w));h=Math.max(.015,Math.min(1-y,h));
 const sx=Math.floor(x*width),sy=Math.floor(y*height),sw=Math.max(1,Math.floor(w*width)),sh=Math.max(1,Math.floor(h*height));
 const factor=Math.min(7,2200/sw,1600/sh);
 const canvas=document.createElement('canvas');
 canvas.width=Math.max(1,Math.round(sw*factor));canvas.height=Math.max(1,Math.round(sh*factor));
 const ctx=canvas.getContext('2d',{willReadFrequently:true});
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
 ctx.drawImage(img,sx,sy,sw,sh,0,0,canvas.width,canvas.height);
 const pixels=ctx.getImageData(0,0,canvas.width,canvas.height),a=pixels.data;
 const hist=new Uint32Array(256);
 for(let i=0;i<a.length;i+=4){const lum=Math.round(a[i]*.299+a[i+1]*.587+a[i+2]*.114);hist[lum]++}
 function percentile(p){let target=canvas.width*canvas.height*p,acc=0;for(let i=0;i<256;i++){acc+=hist[i];if(acc>=target)return i}return 255}
 const middle=percentile(.5),top=percentile(.9),bottom=percentile(.12);
 const isLightOnDark=middle<149;
 let threshold=isLightOnDark?Math.min(215,Math.max(91,top-5)):Math.min(205,Math.max(55,bottom+18));
 if(mode==='bright-soft')threshold+=isLightOnDark?-15:15;
 for(let i=0;i<a.length;i+=4){const lum=a[i]*.299+a[i+1]*.587+a[i+2]*.114;
  let v;if(mode==='bright'||mode==='bright-soft')v=isLightOnDark?(lum>=threshold?0:255):(lum<threshold?0:255);
  else {const normalized=Math.max(0,Math.min(255,(lum-bottom)*255/Math.max(20,top-bottom)));v=isLightOnDark?255-normalized:normalized}
  a[i]=a[i+1]=a[i+2]=v;a[i+3]=255;
 }
 ctx.putImageData(pixels,0,0);return canvas;
}
async function readOdometer(file,onProgress,selectedBox=null){
 if(!ocrReady){await injectScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');ocrReady=true}
 const img=await createImageBitmap(file),readings=[],found=[];
 const manual=!!selectedBox;
 const jobs=manual?[
  {name:'označená oblast – číslice',box:selectedBox,mode:'bright',psm:6,onlyDigits:true,weight:9,manual:true,focus:true},
  {name:'označená oblast – jemnější práh',box:selectedBox,mode:'bright-soft',psm:7,onlyDigits:true,weight:8,manual:true,focus:true}
 ]:[
  {name:'celkové kilometry – detail',box:[.262,.545,.245,.125],mode:'bright',psm:6,onlyDigits:true,weight:7,focus:true},
  {name:'celkové kilometry – jiný kontrast',box:[.262,.545,.245,.125],mode:'bright-soft',psm:7,onlyDigits:true,weight:7,focus:true},
  {name:'dolní displej s označením km',box:[.12,.42,.77,.39],mode:'bright',psm:11,onlyDigits:false,weight:3},
  {name:'celý středový displej',box:[.15,.17,.7,.68],mode:'contrast',psm:11,onlyDigits:false,weight:1}
 ];
 let worker;
 try{
  worker=await Tesseract.createWorker('eng',1,{logger:e=>{if(e.status==='recognizing text')onProgress('Čtení tachometru: '+Math.round((e.progress||0)*100)+' %')}});
  for(const job of jobs){
   onProgress('Hledám kilometry: '+job.name+'…');
   await worker.setParameters({tessedit_pageseg_mode:job.psm,tessedit_char_whitelist:job.onlyDigits?'0123456789 ':''});
   const canvas=odometerImage(img,job.box,job.mode);
   const result=await worker.recognize(canvas),txt=String(result.data.text||'').trim();
   const conf=Number(result.data.confidence)||0;
   readings.push(job.name+': '+(txt||'(nepřečteno)'));
   found.push(...odometerCandidates(txt,job,conf));
  }
 }finally{if(worker)await worker.terminate();img.close?.()}
 const grouped=new Map();
 for(const c of found){let g=grouped.get(c.n);if(!g){g={n:c.n,score:0,hits:0,conf:0,hasKm:false,manual:false,focus:false};grouped.set(c.n,g)}
  g.score+=c.weight;g.hits++;g.conf=Math.max(g.conf,c.conf);g.hasKm ||=c.hasKm;g.manual ||=c.manual;g.focus ||=c.focus;
 }
 const ranking=[...grouped.values()].sort((a,b)=>b.score-a.score||b.hits-a.hits);
 const best=ranking[0],second=ranking[1];
 const consistent=!!best&&(!second||best.score>=second.score+5);
 const reliable=!!best&&consistent&&(
   best.hits>=2 || best.hasKm&&best.conf>=50 || best.focus&&best.conf>=83&&String(best.n).length>=5
 );
 return {km:reliable?String(best.n):'',suggestion:best?String(best.n):'',reliable,
  text:readings.join('\n\n'),alternatives:ranking.slice(1,3).map(r=>r.n)};
}
async function ensurePdf(){if(!pdfReady){await injectScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';pdfReady=true}}
async function readPdf(file,onProgress){await ensurePdf();const d=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise;let text='';for(let i=1;i<=Math.min(d.numPages,8);i++){onProgress(`Čtu PDF: stránka ${i} z ${Math.min(d.numPages,8)}`);const pg=await d.getPage(i),tc=await pg.getTextContent();let pageText=tc.items.map(x=>({text:x.str||'',y:Math.round((x.transform?.[5]||0)/3)*3,x:x.transform?.[4]||0})).sort((a,b)=>b.y-a.y||a.x-b.x).reduce((acc,it)=>{if(!acc.length||acc[acc.length-1].y!==it.y)acc.push({y:it.y,parts:[it.text]});else acc[acc.length-1].parts.push(it.text);return acc},[]).map(row=>row.parts.join(' ')).join('\n');if(pageText.trim().length<25){onProgress(`Rozpoznávám sken PDF: stránka ${i}`);const viewport=pg.getViewport({scale:2});const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;await pg.render({canvasContext:canvas.getContext('2d'),viewport}).promise;pageText=await ocrImage(canvas,onProgress)}text+=pageText+'\n'}return text}
let sheetReady=false;
async function readSpreadsheet(file,onProgress){if(!sheetReady){await injectScript('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js');sheetReady=true}onProgress('Čtu tabulky Excelu…');const wb=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true,cellText:true});return wb.SheetNames.slice(0,12).map(name=>{const sheet=wb.Sheets[name];return 'List '+name+'\n'+XLSX.utils.sheet_to_csv(sheet,{blankrows:false})}).join('\n\n').slice(0,100000)}
async function readDocument(file,onProgress){const n=file.name.toLowerCase();if(n.endsWith('.pdf'))return readPdf(file,onProgress);if(/\.(xlsx|xls|xlsm|csv)$/.test(n))return readSpreadsheet(file,onProgress);if(file.type.startsWith('image/')||/\.(jpg|jpeg|png|webp)$/.test(n))return ocrImage(file,onProgress);throw Error('Nepodporovaný formát. Nahraj PDF, Excel, CSV nebo obrázek.')}
// Částky z faktur: vždy preferujeme „k úhradě / s DPH“, nikoliv „bez DPH“.
function parseInvoiceAmount(value){
 const t=String(value||'').replace(/[\u00a0\u202f\s]/g,'').replace(/[^\d,.-]/g,'');
 if(!t||!/[0-9]/.test(t))return null;
 const comma=t.lastIndexOf(','),dot=t.lastIndexOf('.');let normalized=t;
 if(comma>=0&&dot>=0){const sep=comma>dot?',':'.';normalized=t.replace(sep===','?/\./g:/,/g,'').replace(sep, '.');}
 else if(comma>=0){normalized=/,\d{1,2}$/.test(t)?t.replace(/\./g,'').replace(',','.'):t.replace(/,/g,'');}
 else if(dot>=0){normalized=/\.\d{1,2}$/.test(t)?t.replace(/,/g,''):t.replace(/\./g,'');}
 const n=Number(normalized);return Number.isFinite(n)&&n>=0&&n<=100000000?Math.round(n*100)/100:null;
}
function amountsOnLine(line){
 // Odstranit datové řetězce, čísla faktur, sazby „21 %“ a časové údaje.
 const cleaned=String(line).replace(/\b[0-3]?\d[.\/-][01]?\d[.\/-](?:20)?\d{2,4}\b/g,' ')
  .replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g,' ').replace(/\b\d{1,2}(?:[,.]\d+)?\s*%/g,' ');
 const parts=[...cleaned.matchAll(/(?<![\dA-Za-z])(?:\d{1,3}(?:[ \u00a0\u202f.]\d{3})+|\d{1,9})(?:[,.]\d{1,2})?(?![\dA-Za-z])/g)].map(m=>parseInvoiceAmount(m[0])).filter(n=>n!==null);
 return parts;
}
function extractFields(text){
 const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const d=String(text).match(/\b([0-3]?\d)[.\/\-]\s*([01]?\d)[.\/\-]\s*(20\d\d)\b/);
 const isoDate=d?`${d[3]}-${d[2].padStart(2,'0')}-${d[1].padStart(2,'0')}`:'';
 let gross=null,net=null,vat=null,grossScore=-1,netScore=-1,vatScore=-1;const taxRows=[];
 for(let i=0;i<lines.length;i++){
  const line=lines[i],normalized=line.toLocaleLowerCase('cs-CZ');
  const isWithout=/bez\s*dph|bez\s*dan[eě]|without\s*(?:vat|tax)|excl\.?\s*vat|ex\s*vat|z[aá]klad\s*(?:dan[eě]|dph)|da[nň]ov[yý]\s*z[aá]klad|subtotal|mezisou[cč]et/.test(normalized);
  const isIncluding=/v[cč]\.?\s*dph|v[cč]etn[eě]\s*dph|s\s*dph|po\s*zdan[eě]n[ií]|incl\.?\s*vat|including\s*vat|with\s*vat/.test(normalized);
  const isPayable=/k\s*[uú]hrad[eě]|celkem\s*k\s*zaplacen[ií]|[uú]hrad[aě]|amount\s*due|to\s*pay|k\s*placen[ií]|grand\s*total/.test(normalized);
  const isTotal=/celkem|celkov[aá]\s*(?:cena|[cč][aá]stka)|total|sou[cč]et|fakturovan[aá]\s*[cč][aá]stka/.test(normalized);
  const isVat=/\bdph\b|\bvat\b|da[nň]\s*(?:21|12|15|10|0)?\s*%?|v[yý][sš]e\s*dan[eě]/.test(normalized);
  const values=amountsOnLine(line);
  if(!values.length)continue;
  // Na řádku s číselnou sazbou a částkami bývá konečná částka poslední.
  const last=values[values.length-1];
  const netRank=isWithout?(isTotal?90:80):-1;
  if(netRank>netScore){net=last;netScore=netRank;}
  let grossRank=-1;
  if(isPayable)grossRank=120;
  else if(isIncluding&&isTotal)grossRank=110;
  else if(isIncluding)grossRank=100;
  else if(isTotal&&!isWithout&&!isVat)grossRank=70;
  else if(isTotal&&!isWithout&&isVat&&isIncluding)grossRank=105;
  if(grossRank>grossScore){gross=last;grossScore=grossRank;}
  if(isVat&&!isIncluding&&!isWithout&&!isPayable){
   const vRank=/dph\s*(?:celkem|[cč][aá]stka|[kč][cč])|v[yý][sš]e\s*dan[eě]|vat\s*(?:amount|total)/.test(normalized)?90:60;
   // V typickém řádku sazba / základ / DPH je DPH poslední položka.
   const taxCandidate=last;if(vRank<90)taxRows.push(last);
   if(vRank>vatScore){vat=taxCandidate;vatScore=vRank;}
  }
 }
 // Pokud jsou na faktuře dvě různé sazby, sečteme jednotlivé daňové řádky;
 // řádek explicitně nazvaný „DPH celkem“ však má stále přednost.
 if(vatScore<90&&taxRows.length>1)vat=Math.round(taxRows.reduce((sum,n)=>sum+n,0)*100)/100;
 // Např. OCR řádek „Celkem bez DPH 2000“ se nikdy nesmí vydávat za platbu.
 // Pokud je na faktuře explicitně základ a DPH, lze jejich součet dopočítat.
 let calculated=false;
 if(gross===null&&net!==null&&vat!==null){gross=Math.round((net+vat)*100)/100;calculated=true;}
 if(gross!==null&&net!==null&&vat===null&&gross>=net){vat=Math.round((gross-net)*100)/100;}
 if(gross!==null&&vat!==null&&net===null&&gross>=vat){net=Math.round((gross-vat)*100)/100;}
 const kmMatch=String(text).match(/(?:tachometr|stav\s*km|najeto|kilometr(?:[uůy])?|odo(?:meter)?)\D{0,22}(\d[\d\s]{1,8})\s*(?:km)?/i);
 return {date:isoDate,price:gross??'',priceWithoutVat:net??'',vatAmount:vat??'',calculated,
  needsReview:gross===null,title:lines.find(l=>/v[yý]m[eě]na|olej|filtr|brzdy|servis|oprava|rozvody/i.test(l))?.slice(0,100)||'',
  km:kmMatch?kmMatch[1].replace(/\s/g,''):'',note:String(text).trim()};
}
// Přílohy patří do IndexedDB (Blob), nikoli do malého limitu localStorage.
// Starší záznamy s fileData zůstávají kompatibilní.
const FILE_DB_NAME='mojeauto_prilohy_v2';
let fileDBPromise;
function openFileDB(){
 if(!fileDBPromise)fileDBPromise=new Promise((resolve,reject)=>{
  if(!window.indexedDB){reject(Error('Tento telefon nepodporuje lokální databázi příloh.'));return}
  const req=indexedDB.open(FILE_DB_NAME,1);
  req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('files'))req.result.createObjectStore('files',{keyPath:'id'})};
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||Error('Databázi příloh nelze otevřít'));
 });
 return fileDBPromise;
}
async function writeFiles(entries){
 if(!entries.length)return;
 const d=await openFileDB();await new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readwrite');const store=tx.objectStore('files');
  entries.forEach(entry=>store.put(entry));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||Error('Soubor se nepodařilo uložit'));
  tx.onabort=()=>reject(tx.error||Error('Ukládání přílohy bylo přerušeno'));
 });
}
async function fetchStoredBlob(id){
 const d=await openFileDB();return await new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readonly');const r=tx.objectStore('files').get(id);
  r.onsuccess=()=>resolve(r.result?.blob||null);r.onerror=()=>reject(r.error||Error('Nelze načíst přílohu'));
 });
}
async function removeFiles(ids){
 if(!ids.length)return;
 const d=await openFileDB();await new Promise((resolve,reject)=>{
  const tx=d.transaction('files','readwrite');ids.forEach(id=>tx.objectStore('files').delete(id));
  tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error||Error('Nepodařilo se smazat přílohu'));
 });
}
const fileAsDataURL=blob=>new Promise((resolve,reject)=>{
 const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);
});
function dataURLtoBlob(url){
 const m=String(url||'').match(/^data:([^;,]*)(;base64)?,(.*)$/s);
 if(!m)throw Error('Původní příloha je poškozená');
 const mime=m[1]||'application/octet-stream';
 if(!m[2])return new Blob([decodeURIComponent(m[3])],{type:mime});
 const s=atob(m[3]);const a=new Uint8Array(s.length);
 for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);
 return new Blob([a],{type:mime});
}
function cleanFilename(name){return (String(name||'soubor').replace(/[\\/:*?"<>|\x00-\x1F]/g,'_').slice(0,120).trim()||'soubor')}
async function downloadBlob(blob,filename,share=false){
 const name=cleanFilename(filename);if(!blob)throw Error('Uloženou přílohu nelze načíst');
 if(window.MojeAutoNative?.saveFile){
  const dataUrl=await fileAsDataURL(blob);
  const result=await window.MojeAutoNative.saveFile({name,dataUrl,share});
  if(!share)notice('Uloženo do Dokumenty / MojeAuto: '+name);
  return result;
 }
 if(share&&navigator.canShare&&navigator.canShare({files:[new File([blob],name,{type:blob.type||'application/octet-stream'})]})){
  await navigator.share({files:[new File([blob],name,{type:blob.type||'application/octet-stream'})],title:name});return;
 }
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;
 a.style.display='none';document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),60000);
 if(window.Capacitor?.isNativePlatform?.())notice('Pokud stahování nefunguje, bude potřeba novější APK s podporou ukládání souborů.');
}
function recordFileMetas(r){
 const files=[...(Array.isArray(r.attachments)?r.attachments:[])];
 if(r.fileData)files.unshift({id:'legacy',name:r.fileName||'puvodni-priloha',kind:r.type==='odo'?'tachometr':'faktura',legacy:true});
 return files;
}
async function recordFileBlob(rec,meta){
 if(meta.legacy||meta.id==='legacy')return dataURLtoBlob(rec.fileData);
 const b=await fetchStoredBlob(meta.id);
 if(!b)throw Error('Příloha nebyla nalezena v telefonu. Obnov ji ze zálohy.');return b;
}
async function saveAttachment(rec,meta,share){
 try{const b=await recordFileBlob(rec,meta);await downloadBlob(b,meta.name,share)}
 catch(err){alert('Nelze '+(share?'sdílet':'uložit')+' přílohu: '+(err.message||err))}
}
function storedAttachmentUI(old,removed){
 const target=$('stored-files');if(!target)return;
 const metas=recordFileMetas(old).filter(x=>!removed.has(x.id));
 target.innerHTML=metas.length?metas.map(m=>`<div class="saved-file"><div class="file-name">${html(m.kind==='tachometr'?'📸 ':'📄 ')}${html(m.name)}</div><div class="actions"><button type="button" class="secondary" data-dl="${html(m.id)}">⬇ Uložit</button><button type="button" class="secondary" data-share="${html(m.id)}">Sdílet</button><button type="button" class="ghost" data-rm="${html(m.id)}">Odebrat</button></div></div>`).join(''):'<p class="hint">Zatím žádné uložené přílohy.</p>';
 target.querySelectorAll('[data-dl]').forEach(b=>b.onclick=async()=>{const meta=metas.find(m=>m.id===b.dataset.dl);if(meta)await saveAttachment(old,meta,false)});
 target.querySelectorAll('[data-share]').forEach(b=>b.onclick=async()=>{const meta=metas.find(m=>m.id===b.dataset.share);if(meta)await saveAttachment(old,meta,true)});
 target.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{removed.add(b.dataset.rm);storedAttachmentUI(old,removed)});
}
// Lokální JSON záloha obsahuje i bajty všech vícečetných příloh.
async function backupData(){
 const attachments={};
 for(const r of db.records)for(const m of r.attachments||[]){
  const blob=await fetchStoredBlob(m.id);if(!blob)throw Error('Chybí příloha '+m.name+'; nejdřív ji oprav nebo odeber');
  attachments[m.id]=await fileAsDataURL(blob);
 }
 return {format:'mojeauto-v2',cars:db.cars,records:db.records,attachmentBlobs:attachments};
}
function renderCarBiographyButton(){
 if(activeCar&&$('stats')){
  const b=document.createElement('button');b.id='export-bio';b.type='button';b.className='secondary';
  b.textContent='📄 Stáhnout životopis auta (PDF)';
  const parent=$('stats');if(!parent.querySelector('#export-bio'))parent.appendChild(b);
  b.onclick=()=>exportBiography(activeCar);
 }
}
// Jednoduchý PDF zapisovač: česká diakritika se vykreslí v prohlížeči
// na A4 a fotografie stránek se vloží do PDF. Bez přenosu dat a bez CDN.
function imagePagesToPdf(jpegs,width,height){
 const encoder=new TextEncoder(),chunks=[],offsets=[];let length=0;
 function append(data){const arr=typeof data==='string'?encoder.encode(data):data;chunks.push(arr);length+=arr.length;}
 function begin(id){offsets[id]=length;append(`${id} 0 obj\n`)}
 function end(){append('\nendobj\n')}
 append('%PDF-1.4\n');
 begin(1);append('<< /Type /Catalog /Pages 2 0 R >>');end();
 begin(2);append(`<< /Type /Pages /Count ${jpegs.length} /Kids [${jpegs.map((_,i)=>3+3*i+' 0 R').join(' ')}] >>`);end();
 for(let i=0;i<jpegs.length;i++){
  const pageId=3+3*i,imgId=pageId+1,contentId=pageId+2;
  const raw=atob(jpegs[i].split(',')[1]),image=new Uint8Array(raw.length);
  for(let j=0;j<raw.length;j++)image[j]=raw.charCodeAt(j);
  begin(pageId);append(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 ${imgId} 0 R >> >> /Contents ${contentId} 0 R >>`);end();
  begin(imgId);append(`<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${image.length} >>\nstream\n`);
  append(image);append('\nendstream');end();
  const content='q\n595.28 0 0 841.89 0 0 cm\n/Im0 Do\nQ\n';
  begin(contentId);append(`<< /Length ${encoder.encode(content).length} >>\nstream\n${content}endstream`);end();
 }
 const xref=length;append(`xref\n0 ${offsets.length}\n0000000000 65535 f \n`);
 for(let i=1;i<offsets.length;i++)append(`${String(offsets[i]).padStart(10,'0')} 00000 n \n`);
 append(`trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
 return new Blob(chunks,{type:'application/pdf'});
}
async function exportBiography(carId){
 const car=db.cars.find(x=>x.id===carId);if(!car)return notice('Vyber auto');
 const button=$('export-bio');if(button)button.disabled=true;
 try{
  const pageImages=[];
  const rows=db.records.filter(r=>r.carId===carId).slice().sort((a,b)=>(a.date||'').localeCompare(b.date||''));
  const total=rows.filter(r=>r.type==='service').reduce((sum,r)=>sum+Number(r.price||0),0);
  const maxKm=rows.reduce((m,r)=>Math.max(m,Number(r.km)||0),0);
  // Stránka je vykreslená přes systémový font, proto PDF správně zobrazuje českou diakritiku.
  const c=document.createElement('canvas');c.width=1240;c.height=1754;
  const ctx=c.getContext('2d');const pad=78,usable=c.width-2*pad;
  let y=80,pageNo=0;
  function line(txt,size=23,bold=false,color='#203247',indent=0){
   ctx.font=`${bold?'700':'400'} ${size}px Arial, sans-serif`;ctx.fillStyle=color;
   const words=String(txt||'').split(/\s+/);let l='';
   for(const w of words){const candidate=l?l+' '+w:w;
    if(ctx.measureText(candidate).width>usable-indent&&l){if(y>1620)newPage();ctx.fillText(l,pad+indent,y);y+=size*1.4;l=w;}
    else l=candidate;
   }
   if(l){if(y>1620)newPage();ctx.fillText(l,pad+indent,y);y+=size*1.4;}
  }
  function newPage(){
   if(pageNo>0)pageImages.push(c.toDataURL('image/jpeg',.86));
   pageNo++;ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);
   ctx.fillStyle='#123d62';ctx.fillRect(0,0,c.width,18);
   ctx.font='18px Arial, sans-serif';ctx.fillStyle='#6b7c90';ctx.fillText('MOJE AUTO • SERVISNÍ HISTORIE',pad,1712);y=80;
  }
  newPage();line('ŽIVOTOPIS AUTA',41,true,'#123d62');y+=10;
  line(`${car.brand||''} ${car.model||''}`,34,true);line(`SPZ: ${car.plate||'—'}   VIN: ${car.vin||'—'}`);
  line(`Rok výroby: ${car.year||'—'}   Vygenerováno: ${date(today())}`,20);
  y+=16;line(`Stav km v historii: ${maxKm?maxKm.toLocaleString('cs-CZ')+' km':'neuvedeno'}`,25,true);
  line(`Celkové servisní náklady včetně DPH: ${money(total)}`,25,true);y+=20;
  line(`SERVISNÍ UDÁLOSTI (${rows.length})`,29,true,'#123d62');y+=14;
  if(!rows.length)line('Zatím žádný servisní záznam.');
  for(const [i,r] of rows.entries()){
   if(y>1470)newPage();
   line(`${i+1}. ${date(r.date)} — ${r.title||'Servis'}`,25,true,'#1e4c72');
   line(`Kilometry: ${r.km?Number(r.km).toLocaleString('cs-CZ')+' km':'—'}   Cena s DPH: ${r.type==='service'?money(r.price):'—'}`,20);
   if(r.type==='service'&&(r.priceWithoutVat||r.vatAmount))line(`Bez DPH: ${r.priceWithoutVat!==''&&r.priceWithoutVat!=null?money(r.priceWithoutVat):'—'}   DPH: ${r.vatAmount!==''&&r.vatAmount!=null?money(r.vatAmount):'—'}`,19);
   if(r.note)line('Poznámka: '+r.note,19,false,'#34495e');
   const files=recordFileMetas(r);
   if(files.length){line('Přílohy:',19,true);for(const m of files)line('• '+m.name+(m.kind==='tachometr'?' (tachometr)':''),18,false,'#34495e',15);}
   y+=18;
  }
  pageImages.push(c.toDataURL('image/jpeg',.86));
  const blob=imagePagesToPdf(pageImages,c.width,c.height);
  await downloadBlob(blob,`Zivotopis_${car.brand}_${car.model}_${car.plate||'auto'}.pdf`);
 }catch(err){alert('Nepodařilo se vytvořit PDF: '+(err.message||err))}
 finally{if(button)button.disabled=false}
}

function setupPhotoTools(old,isOdo,removed=new Set()){
 const inp=$('photo-upload'),canvas=$('redact-canvas'),wrap=$('redact-tools'),ctx=canvas.getContext('2d');
 const odoCanvas=isOdo?$('odo-select-canvas'):null,odoWrap=isOdo?$('odo-select-tools'):null;
 let image=null,rects=[],begin=null,removeOld=false;
 let odoView=[0,.30,1,.70],odoRect=null,odoBegin=null;
 function repaint(){if(!image)return;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);ctx.fillStyle='#000';rects.forEach(r=>ctx.fillRect(r.x,r.y,r.w,r.h))}
 function point(ev,c){const b=c.getBoundingClientRect();return{x:(ev.clientX-b.left)*c.width/b.width,y:(ev.clientY-b.top)*c.height/b.height}}
 // Začernění faktury je nezávislé na výběru oblasti pro OCR tachometru.
 canvas.onpointerdown=e=>{if(!image)return;begin=point(e,canvas);canvas.setPointerCapture(e.pointerId)};
 canvas.onpointerup=e=>{if(!begin)return;const end=point(e,canvas),r={x:Math.min(begin.x,end.x),y:Math.min(begin.y,end.y),w:Math.abs(begin.x-end.x),h:Math.abs(begin.y-end.y)};if(r.w>6&&r.h>6)rects.push(r);begin=null;repaint()};
 $('redact-undo').onclick=()=>{rects.pop();repaint()};$('redact-reset').onclick=()=>{rects=[];repaint()};
 function repaintOdo(){if(!image||!odoCanvas)return;
  const c=odoCanvas.getContext('2d'),[x,y,w,h]=odoView;
  const iw=image.naturalWidth||image.width,ih=image.naturalHeight||image.height;
  c.drawImage(image,iw*x,ih*y,iw*w,ih*h,0,0,odoCanvas.width,odoCanvas.height);
  const r=odoRect||odoBegin;
  if(r){c.fillStyle='rgba(36,153,230,.18)';c.strokeStyle='#27d5ff';c.lineWidth=4;
   const a=(r.x-x)/w*odoCanvas.width,b=(r.y-y)/h*odoCanvas.height,d=r.w/w*odoCanvas.width,e=r.h/h*odoCanvas.height;
   c.fillRect(a,b,d,e);c.strokeRect(a,b,d,e)}
 }
 function odoPoint(ev){const v=point(ev,odoCanvas),[x,y,w,h]=odoView;return{x:x+v.x/odoCanvas.width*w,y:y+v.y/odoCanvas.height*h}}
 function odoSelection(start,end){const [x,y,w,h]=odoView;const l=Math.max(x,Math.min(start.x,end.x)),t=Math.max(y,Math.min(start.y,end.y));return{x:l,y:t,w:Math.min(x+w,Math.max(start.x,end.x))-l,h:Math.min(y+h,Math.max(start.y,end.y))-t}}
 if(odoCanvas){
  odoCanvas.onpointerdown=e=>{if(!image)return;odoCanvas.setPointerCapture(e.pointerId);odoBegin={start:odoPoint(e),current:odoPoint(e)};odoRect=null};
  odoCanvas.onpointermove=e=>{if(!odoBegin)return;odoBegin.current=odoPoint(e);const temp=odoSelection(odoBegin.start,odoBegin.current);odoRect=temp;repaintOdo()};
  odoCanvas.onpointerup=e=>{if(!odoBegin)return;const r=odoSelection(odoBegin.start,odoPoint(e));odoBegin=null;odoRect=r.w>=.018&&r.h>=.012?r:null;$('odo-read-selected').disabled=!odoRect;repaintOdo()};
  odoCanvas.onpointercancel=()=>{odoBegin=null;repaintOdo()};
  $('odo-view-toggle').onclick=()=>{odoView=odoView[1]===0?[0,.30,1,.70]:[0,0,1,1];odoRect=null;$('odo-read-selected').disabled=true;$('odo-view-toggle').textContent=odoView[1]===0?'Zobrazit spodní část':'Zobrazit celý snímek';repaintOdo()};
 }
 $('remove-attachment').onclick=()=>{removeOld=true;inp.value='';image=null;rects=[];odoRect=null;wrap.hidden=true;if(odoWrap)odoWrap.hidden=true;$('attached').textContent='Příloha bude odstraněna při uložení.'};
 async function loadImage(file){const u=URL.createObjectURL(file);try{const im=new Image();await new Promise((ok,no)=>{im.onload=ok;im.onerror=no;im.src=u});image=im;
  const scale=Math.min(1,1400/im.width,1400/im.height);canvas.width=Math.max(1,Math.round(im.width*scale));canvas.height=Math.max(1,Math.round(im.height*scale));rects=[];wrap.hidden=isOdo;repaint();
  if(odoCanvas){odoView=[0,.30,1,.70];odoRect=null;odoCanvas.width=Math.min(1200,im.width);odoCanvas.height=Math.max(1,Math.round(odoCanvas.width*im.height*.70/im.width));odoWrap.hidden=false;$('odo-read-selected').disabled=true;$('odo-view-toggle').textContent='Zobrazit celý snímek';repaintOdo()}
 }finally{URL.revokeObjectURL(u)}}
 inp.onchange=async()=>{const f=inp.files[0];if(!f)return;removeOld=false;const isImg=f.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(f.name);if(isImg){try{await loadImage(f)}catch{notice('Fotografii nelze otevřít')}}else{image=null;wrap.hidden=true;if(odoWrap)odoWrap.hidden=true} $('attached').textContent='Nová příloha: '+f.name;if(isOdo&&isImg&&image)doOCR();};
 async function doOCR(box=null){
  const saved=[];
  if(!isOdo)for(const m of recordFileMetas(old).filter(m=>m.kind!=='tachometr'&&!removed.has(m.id))){
   const blob=await recordFileBlob(old,m);saved.push(new File([blob],m.name,{type:m.mime||blob.type}));
  }
  const fresh=[...(inp.files.length?[inp.files[0]]:[]),...(!isOdo&&$('extra-files')?[...$('extra-files').files]:[])];
  const sources=[...saved,...fresh],f=isOdo?inp.files[0]:sources[0];
  if(!f){notice('Nejdříve přilož fotografii, PDF nebo Excel');return}

  const btn=$('run-ocr'),selectedBtn=isOdo?$('odo-read-selected'):null;btn.disabled=true;if(selectedBtn)selectedBtn.disabled=true;
  try{$('ocr-progress').textContent='Načítám čtení dokladů…';
   const isImg=f.type.startsWith('image/')||/\.(jpe?g|png|webp)$/i.test(f.name);
   if(isOdo&&isImg){const out=await readOdometer(f,s=>$('ocr-progress').textContent=s,box);
    $('ocr-text').value=out.text;
    if(out.km)$('rec-km').value=out.km;
    $('ocr-progress').textContent=out.reliable?'✅ Odečteno '+Number(out.km).toLocaleString('cs-CZ')+' km. Zkontroluj číslo na fotografii před uložením.':
      (out.suggestion?'⚠️ Nejistý odečet: možná '+Number(out.suggestion).toLocaleString('cs-CZ')+' km. Zkontroluj a doplň počet km ručně.':'⚠️ Kilometry se nepodařilo bezpečně určit. Označ prstem na fotografii jen číslice a klikni na „Přečíst označené km“.');
   }else{
    let totalGross=0,totalNet=0,totalVat=0,allGross=true,allNet=true,allVat=true,combined=[];
    let anyGross=false,first=null;
    for(let i=0;i<sources.length;i++){
     const current=sources[i];$('ocr-progress').textContent=`Čtu fakturu ${i+1}/${sources.length}: ${current.name}…`;
     const txt=await readDocument(current,s=>$('ocr-progress').textContent=`${current.name}: ${s}`),data=extractFields(txt);
     first ||= data;
     const moneyText=data.price!==''?Number(data.price).toLocaleString('cs-CZ')+' Kč (vč. DPH)':'⚠️ cena včetně DPH nenalezena';
     combined.push(`=== ${current.name} ===\n${txt}\n--- Výsledek: ${moneyText}${data.calculated?' (součet základu a uvedené DPH)':''} ---`);
     if(data.price==='')allGross=false;else{totalGross+=Number(data.price);anyGross=true}
     if(data.priceWithoutVat==='')allNet=false;else totalNet+=Number(data.priceWithoutVat);
     if(data.vatAmount==='')allVat=false;else totalVat+=Number(data.vatAmount);
    }
    $('ocr-text').value=combined.join('\n\n');
    if(first?.date)$('rec-date').value=first.date;
    if(first?.km)$('rec-km').value=first.km;
    if(first?.title&&!$('rec-title').value)$('rec-title').value=first.title;
    if(allGross&&anyGross)$('rec-price').value=(Math.round(totalGross*100)/100).toFixed(2);
    if(allNet&&sources.length)$('rec-net').value=(Math.round(totalNet*100)/100).toFixed(2);
    if(allVat&&sources.length)$('rec-vat').value=(Math.round(totalVat*100)/100).toFixed(2);
    $('ocr-progress').textContent=allGross&&anyGross?
     `✅ Načteno ${sources.length} dokladů, celkem s DPH: ${money(totalGross)}. Ověř částku před uložením.`:
     '⚠️ Některý doklad obsahuje jen cenu bez DPH nebo nemá čitelnou částku. Součet s DPH jsem nepřepsal, doplň ho ručně.';
   }
  }catch(e){$('ocr-progress').textContent='Chyba: '+e.message}finally{btn.disabled=false;if(selectedBtn)selectedBtn.disabled=!odoRect}
 }
 $('run-ocr').onclick=()=>doOCR();
 if(isOdo)$('odo-read-selected').onclick=()=>{
  if(!odoRect)return;
  // Výběr mírně rozšíříme, aby nedošlo k odříznutí krajních číslic.
  const x=Math.max(0,odoRect.x-.014),y=Math.max(0,odoRect.y-.013);
  doOCR([x,y,Math.min(1-x,odoRect.w+.028),Math.min(1-y,odoRect.h+.026)]);
 };
 return {async attachment(){
  const file=inp.files[0];if(!file)return null;
  if(file.size>25*1024*1024)throw Error('Příloha je větší než 25 MB.');
  // Původní fotografii zachováme, dokud uživatel skutečně něco nezačerní.
  if(image&&rects.length){repaint();const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Obrázek nelze uložit')),'image/jpeg',.90));
   return new File([blob],file.name.replace(/\.[^.]+$/,'')+'-zacerneno.jpg',{type:'image/jpeg'});
  }
  return file;
 }};
}
function openRecord(id,type='service'){
 if(!db.cars.length){notice('Nejdřív přidej auto');showTab('overview');return}
 const old=db.records.find(r=>r.id===id)||{},isOdo=(old.type||type)==='odo';
 const cs=db.cars.map(c=>`<option value="${html(c.id)}" ${(old.carId||activeCar)===c.id?'selected':''}>${html(c.brand+' '+c.model)}</option>`).join('');
 const vatFields=isOdo?'':`<div class="price-fields">${old.type==='service'&&old.priceWithoutVat===undefined&&Number(old.price)>0?'<p class="warning">Starší záznam: dřívější OCR mohlo uložit cenu bez DPH. Zkontroluj faktury a uprav částku celkem s DPH.</p>':''}<label>Cena bez DPH (Kč)<input id="rec-net" name="priceWithoutVat" type="number" step="0.01" min="0" value="${html(old.priceWithoutVat??'')}"></label><label>DPH (Kč)<input id="rec-vat" name="vatAmount" type="number" step="0.01" min="0" value="${html(old.vatAmount??'')}"></label><label><strong>Celkem zaplaceno včetně DPH (Kč)</strong><input id="rec-price" name="price" type="number" step="0.01" min="0" value="${html(old.price??'')}"></label><button type="button" class="secondary" id="sum-vat">Spočítat bez DPH + DPH</button><p class="hint">Do nákladů auta se započítá pouze „Celkem zaplaceno včetně DPH“. Pokud faktura uvádí jen základ bez DPH, částku ověř.</p></div>`;
 const serviceOdo=isOdo?'':`<div class="panel compact"><h3>📸 Tachometr při servisu</h3><label>Přiložit fotografii tachometru<input type="file" id="service-odo-upload" accept="image/*"></label><button id="service-odo-read" type="button" class="secondary">🔎 Načíst km z fotografie</button><p id="service-odo-progress" class="hint">Fotografie se uloží ke stejnému servisnímu záznamu.</p></div>`;
 const extraFiles=isOdo?'':`<label>Další faktury / doklady ke stejnému servisu<input id="extra-files" type="file" multiple accept="image/*,.pdf,.xlsx,.xls,.xlsm,.csv,application/pdf"></label><p class="hint">Můžeš vybrat několik PDF, obrázků nebo Excelů najednou. Každý dokument se uloží a bude samostatně ke stažení.</p><div id="new-files-list" class="filelist"></div>`;
 const content=`<label>Auto<select name="carId">${cs}</select></label><label>Datum<input id="rec-date" type="date" name="date" required value="${html(old.date||today())}"></label><label>Název záznamu<input id="rec-title" name="title" required value="${html(old.title||(isOdo?'Stav tachometru':''))}" placeholder="Výměna oleje, brzdy…"></label><label>Kilometry<input id="rec-km" name="km" type="number" min="0" ${isOdo?'required':''} inputmode="numeric" value="${html(old.km??'')}"></label>${vatFields}<label>Poznámky<textarea name="note" rows="3">${html(old.note||'')}</textarea></label>${serviceOdo}<label>${isOdo?'Fotografie tachometru':'Faktura pro OCR a případné začernění'}<input name="photo" id="photo-upload" type="file" accept="${isOdo?'image/*':'image/*,.pdf,.xlsx,.xls,.xlsm,.csv,application/pdf'}"></label>${extraFiles}<button type="button" id="run-ocr" class="secondary read-btn">🔎 ${isOdo?'Přečíst kilometry':'Přečíst všechny faktury (i uložené)'}</button><div id="ocr-progress" aria-live="polite">Čtení spustíš po nahrání. Vyžaduje internet při načtení OCR.</div>${isOdo?`<div id="odo-select-tools" hidden><p><b>📍 Přesnější načtení kilometrů</b></p><p class="hint">Pokud se km nepřečtou, prstem označ na fotografii jen číslice.</p><canvas id="odo-select-canvas" style="width:100%;height:auto;border:1px solid #9caec4;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="odo-read-selected" class="secondary" disabled>🔎 Přečíst označené km</button><button type="button" id="odo-view-toggle" class="ghost">Zobrazit celý snímek</button></div></div>`:''}<label>Rozpoznaný text – lze vymazat či opravit<textarea id="ocr-text" name="ocrText" rows="6" placeholder="Text rozpoznaný z faktury">${html(old.ocrText||'')}</textarea></label><div id="redact-tools" hidden><p><b>Začernění údajů na fotografii</b></p><p class="hint">Prstem označ část fotografie ke skrytí. Při začernění se uloží jen upravená verze.</p><canvas id="redact-canvas" style="width:100%;height:auto;border:1px solid #b9c6d7;border-radius:10px;touch-action:none"></canvas><div class="actions"><button type="button" id="redact-undo" class="secondary">↶ Vrátit poslední</button><button type="button" id="redact-reset" class="ghost">Zrušit začernění</button></div></div><div class="actions"><button type="button" class="ghost" id="remove-attachment">🗑 Odebrat nově vybranou přílohu</button></div><div id="attached" class="note">Vybraný soubor není</div><h3>Uložené faktury a fotografie</h3><div id="stored-files"></div><p class="warning">Přepis OCR může být nepřesný. Konečnou cenu s DPH vždy zkontroluj podle faktury. Začernění originálního PDF nebo Excelu nepodporujeme; u těchto souborů upravíš jen přepis.</p>`;
 let tools;const removed=new Set();
 modal(id?'Upravit záznam':(isOdo?'Nový stav tachometru':'Nová servisní událost'),content,async f=>{
  const submit=$('editor-form').querySelector('[type=submit]');submit.disabled=true;
  let entries=[];
  try{
   const primary=await tools.attachment();
   const pending=[];
   if(primary)pending.push({file:primary,kind:isOdo?'tachometr':'faktura'});
   if(!isOdo){
    const odoPhoto=$('service-odo-upload').files[0];if(odoPhoto)pending.push({file:odoPhoto,kind:'tachometr'});
    for(const file of $('extra-files').files)pending.push({file,kind:'faktura'});
   }
   if(pending.some(x=>x.file.size>25*1024*1024))throw Error('Jedna příloha může mít nejvýše 25 MB.');
   entries=pending.map(x=>{const id=uid();return {id,blob:x.file,meta:{id,name:x.file.name,kind:x.kind,mime:x.file.type||'application/octet-stream',size:x.file.size}}});
   await writeFiles(entries.map(({id,blob})=>({id,blob})));
   const kept=recordFileMetas(old).filter(m=>!m.legacy&&!removed.has(m.id));
   const gross=Number(f.get('price')),net=Number(f.get('priceWithoutVat')),vat=Number(f.get('vatAmount'));
   const record={id:id||uid(),type:isOdo?'odo':'service',carId:f.get('carId'),date:f.get('date'),title:f.get('title').trim(),km:f.get('km'),
    price:isOdo?0:(f.get('price')===''?'':gross),priceWithoutVat:isOdo?'':(f.get('priceWithoutVat')===''?'':net),
    vatAmount:isOdo?'':(f.get('vatAmount')===''?'':vat),note:f.get('note').trim(),ocrText:f.get('ocrText').trim(),
    fileData:removed.has('legacy')?'':(old.fileData||''),fileName:removed.has('legacy')?'':(old.fileName||''),
    attachments:[...kept,...entries.map(e=>e.meta)]};
   if(!isOdo&&record.price===''&&record.priceWithoutVat!==''){
    if(!confirm('Není zadána cena včetně DPH. Uložit záznam bez započtení částky do nákladů?')){
     await removeFiles(entries.map(e=>e.id));return;
    }
   }
   const before=db.records;
   db.records=id?db.records.map(r=>r.id===id?record:r):[...db.records,record];
   if(!save()){db.records=before;await removeFiles(entries.map(e=>e.id));return;}
   const toDelete=[...removed].filter(x=>x!=='legacy');
   try{await removeFiles(toDelete)}catch(e){console.warn('Úklid souborů:',e)}
   close();notice('Servis a přílohy uloženy');
  }catch(err){try{await removeFiles(entries.map(e=>e.id))}catch{}alert('Uložení se nezdařilo: '+(err.message||err))}
  finally{submit.disabled=false}
 },id?async()=>{
  const before=db.records;db.records=db.records.filter(r=>r.id!==id);
  if(!save()){db.records=before;return false;}
  await removeFiles((old.attachments||[]).map(x=>x.id));return true;
 }:null);
 storedAttachmentUI(old,removed);
 tools=setupPhotoTools(old,isOdo,removed);
 if(!isOdo){
  $('sum-vat').onclick=()=>{
   const n=$('rec-net').value,v=$('rec-vat').value;
   if(n===''||v===''){notice('Vyplň nejdříve základ i částku DPH.');return}
   $('rec-price').value=(Math.round((Number(n)+Number(v))*100)/100).toFixed(2);
  };
  const other=$('extra-files');
  other.onchange=()=>{$('new-files-list').textContent=[...other.files].map(f=>f.name).join(' • ')};
  $('service-odo-read').onclick=async()=>{
   const file=$('service-odo-upload').files[0];if(!file){notice('Vyber fotografii tachometru');return}
   const status=$('service-odo-progress');try{status.textContent='Rozpoznávám…';
    const result=await readOdometer(file,s=>status.textContent=s);
    if(result.km)$('rec-km').value=result.km;
    status.textContent=result.reliable?'✅ Rozpoznáno '+Number(result.km).toLocaleString('cs-CZ')+' km. Ověř na snímku.':
      '⚠️ Nejistý odečet '+(result.suggestion||'')+'. Zadej km podle fotografie ručně.';
   }catch(e){status.textContent='Chyba: '+e.message}
  };
 }
}
$('add-invoice').onclick=()=>openRecord(null,'service');$('add-service').onclick=()=>openRecord(null,'service');$('add-odo').onclick=()=>openRecord(null,'odo');$('history-add').onclick=()=>openRecord(null,'service');
$('export').onclick=async()=>{
 const b=$('export');b.disabled=true;
 try{const json=await backupData();await downloadBlob(new Blob([JSON.stringify(json)],{type:'application/json'}),'moje-auto-zaloha-'+today()+'.json')}
 catch(e){alert('Zálohu nelze vytvořit: '+(e.message||e))}finally{b.disabled=false}
};
$('import-button').onclick=()=>$('import-file').click();
$('import-file').onchange=async e=>{
 try{const file=e.target.files?.[0];if(!file)return;const x=JSON.parse(await file.text());
  if(!Array.isArray(x.cars)||!Array.isArray(x.records))throw Error('Nesprávný formát zálohy');
  if(!confirm('Obnovit zálohu? Aktuální záznamy budou nahrazeny.'))return;
  const stored=[];
  for(const [id,dataUrl] of Object.entries(x.attachmentBlobs||{})){
   if(!/^[a-z\d-]{5,80}$/i.test(id))throw Error('Neplatný identifikátor přílohy');
   stored.push({id,blob:dataURLtoBlob(dataUrl)});
  }
  await writeFiles(stored);const before=db;db={cars:x.cars,records:x.records};
  if(save()){activeCar=null;render();notice('Záloha obnovena')}else{db=before;throw Error('Nedostatek místa pro záznamy')}
 }catch(err){alert('Zálohu nelze obnovit: '+(err.message||err))}finally{e.target.value=''}
};
$('settings').querySelector('h2').textContent='Nastavení a záloha';$('settings').querySelector('.panel').style.display='none';
render();if(activeCar)attachRecords();
if('serviceWorker'in navigator && location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
